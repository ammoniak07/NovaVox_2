<?php

namespace Octfx\ScDataDumper\Tests\Helper;

use DOMDocument;
use DOMXPath;
use Octfx\ScDataDumper\Helper\Element;
use Octfx\ScDataDumper\Helper\XmlAccess;
use Octfx\ScDataDumper\Tests\Fixtures\ScDataTestCase;
use Octfx\ScDataDumper\Tests\Fixtures\TestRootDocument;

class XmlAccessTraitTest extends ScDataTestCase
{
    protected DOMDocument $domDocument;

    protected DOMXPath $domXPath;

    protected XmlAccessTestClass $testInstance;

    protected function setUp(): void
    {
        parent::setUp();

        // Create a test DOMDocument
        $this->domDocument = new DOMDocument;
        $this->domDocument->loadXML('<?xml version="1.0" encoding="UTF-8"?>
<root>
    <child>
        <grandchild>value</grandchild>
    </child>
    <level1>
        <level2>
            <level3>
                <level4>deep value</level4>
            </level3>
        </level2>
    </level1>
</root>');

        // Create XPath instance
        $this->domXPath = new DOMXPath($this->domDocument);

        // Create test instance using a class that uses the XmlAccess trait
        $this->testInstance = new XmlAccessTestClass($this->domDocument);
    }

    /**
     * Test XPath-based child queries on Element instances
     */
    public function test_get_with_path(): void
    {
        // Create an Element from the root node
        $rootElement = new Element($this->domDocument->documentElement);

        // Test 1: Get grandchild element using 2-level path
        $grandchild = $rootElement->get('child/grandchild');
        $this->assertInstanceOf(Element::class, $grandchild, 'Should return Element for valid child/grandchild path');
        $this->assertEquals('grandchild', $grandchild->nodeName, 'Should return grandchild element');

        // Test 2: Get element from 3+ level path
        $deepElement = $rootElement->get('level1/level2/level3/level4');
        $this->assertInstanceOf(Element::class, $deepElement, 'Should return Element for valid 4-level path');
        $this->assertEquals('level4', $deepElement->nodeName, 'Should return level4 element');

        // Test 3: Get non-existent path returns default value
        $default = 'default_value';
        $nonExistent = $rootElement->get('nonexistent/path', $default);
        $this->assertEquals($default, $nonExistent, 'Should return default value for non-existent path');
    }

    /**
     * Test attribute retrieval with @ prefix from Element instances
     */
    public function test_get_attribute(): void
    {
        // Create a DOMDocument with elements and attributes
        $this->domDocument = new DOMDocument;
        $this->domDocument->loadXML('<?xml version="1.0" encoding="UTF-8"?>
<root name="root_name" id="1">
    <child title="child_title">
        <grandchild value="123" type="text">
            <deep number="456.78" />
        </grandchild>
    </child>
</root>');

        // Create XPath instance
        $this->domXPath = new DOMXPath($this->domDocument);

        // Create test instance using a class that uses the XmlAccess trait
        $this->testInstance = new XmlAccessTestClass($this->domDocument);

        // Create an Element from the root node
        $rootElement = new Element($this->domDocument->documentElement);

        // Test 1: Direct attribute access returns string value
        $name = $rootElement->get('@name');
        $this->assertEquals('root_name', $name, 'Should return attribute value as string');

        // Test 2: Numeric attribute returns float
        $id = $rootElement->get('@id');
        $this->assertEquals(1.0, $id, 'Should return numeric attribute as float');
        $this->assertIsFloat($id, 'Numeric attribute should be float type');

        // Test 3: Path + attribute query returns attribute from that element
        $title = $rootElement->get('child@title');
        $this->assertEquals('child_title', $title, 'Should return attribute value from child element');

        // Test 4: Deep path + attribute query
        $value = $rootElement->get('child/grandchild@value');
        $this->assertEquals(123.0, $value, 'Should return numeric attribute from deep path as float');
        $this->assertIsFloat($value, 'Numeric attribute should be float type');

        // Test 5: Float attribute conversion
        $number = $rootElement->get('child/grandchild/deep@number');
        $this->assertEquals(456.78, $number, 'Should return float attribute as float type');
        $this->assertIsFloat($number, 'Float attribute should be float type');

        // Test 6: Non-existent attribute returns default value
        $default = 'default_value';
        $missing = $rootElement->get('@missing', $default);
        $this->assertEquals($default, $missing, 'Should return default value for non-existent attribute');

        // Test 7: Non-existent attribute on non-existent path returns default
        $missingPath = $rootElement->get('nonexistent/path@attr', $default);
        $this->assertEquals($default, $missingPath, 'Should return default value for non-existent path with attribute');
    }

    /**
     * Test relative vs absolute path lookups with Element context
     */
    public function test_get_relative_and_absolute_paths(): void
    {
        $domDocument = new DOMDocument;
        $domDocument->loadXML('<?xml version="1.0" encoding="UTF-8"?>
<root>
    <parent>
        <child id="1" />
    </parent>
    <child id="2" />
</root>');

        $parentNode = $domDocument->getElementsByTagName('parent')->item(0);
        $parentElement = new Element($parentNode);

        $relativeId = $parentElement->get('child@id');
        $this->assertIsFloat($relativeId, 'Relative attribute query should return numeric float');
        $this->assertEquals(1.0, $relativeId, 'Relative path should resolve against the current element');

        $absoluteId = $parentElement->get('/root/child@id');
        $this->assertIsFloat($absoluteId, 'Absolute attribute query should return numeric float');
        $this->assertEquals(2.0, $absoluteId, 'Absolute path should resolve against the document root');

        $absoluteChild = $parentElement->get('/root/child');
        $this->assertInstanceOf(Element::class, $absoluteChild, 'Absolute element query should return Element');
        $this->assertEquals('child', $absoluteChild->nodeName, 'Absolute element query should return the root child node');
        $this->assertEquals('2', $absoluteChild->getAttribute('id'), 'Absolute element should expose correct attribute value');
    }

    /**
     * Test predicate handling and alternate attribute syntax
     */
    public function test_get_with_predicate_and_slash_attribute(): void
    {
        $domDocument = new DOMDocument;
        $domDocument->loadXML('<?xml version="1.0" encoding="UTF-8"?>
<root>
    <item type="weapon" code="W1" />
    <item type="armor" code="A1" />
    <item type="armor" />
</root>');

        $rootElement = new Element($domDocument->documentElement);

        $armorCode = $rootElement->get("item[@type='armor']@code");
        $this->assertEquals('A1', $armorCode, 'Predicate should filter elements before attribute lookup');

        $armorCodeSlash = $rootElement->get("item[@type='armor']/@code");
        $this->assertEquals('A1', $armorCodeSlash, 'Slash attribute syntax should match path@attr behavior');

        $missing = $rootElement->get("item[@type='shield']@code", 'default_value');
        $this->assertEquals('default_value', $missing, 'Predicate with no match should return default value');
    }

    /**
     * Test that only the first matching node is returned
     */
    public function test_get_returns_first_match(): void
    {
        $domDocument = new DOMDocument;
        $domDocument->loadXML('<?xml version="1.0" encoding="UTF-8"?>
<root>
    <entry id="1" />
    <entry id="2" />
</root>');

        $rootElement = new Element($domDocument->documentElement);
        $firstId = $rootElement->get('entry@id');

        $this->assertIsFloat($firstId, 'Numeric attribute should be returned as float');
        $this->assertEquals(1.0, $firstId, 'Should return the first matching attribute value');
    }

    /**
     * Test that all matching elements are returned
     */
    public function test_get_all_returns_all_matching_elements(): void
    {
        $domDocument = new DOMDocument;
        $domDocument->loadXML('<?xml version="1.0" encoding="UTF-8"?>
<root>
    <entry id="1" />
    <entry id="2" />
    <group>
        <entry id="3" />
    </group>
</root>');

        $rootElement = new Element($domDocument->documentElement);
        $entries = $rootElement->getAll('entry');

        $this->assertCount(2, $entries, 'Should return every matching child element');
        $this->assertContainsOnlyInstancesOf(Element::class, $entries, 'Should wrap matches as Element instances');
        $this->assertEquals('1', $entries[0]->getAttribute('id'), 'First result should keep document order');
        $this->assertEquals('2', $entries[1]->getAttribute('id'), 'Second result should keep document order');
    }

    /**
     * Test that all matching attribute values are returned
     */
    public function test_get_all_returns_all_matching_attribute_values(): void
    {
        $domDocument = new DOMDocument;
        $domDocument->loadXML('<?xml version="1.0" encoding="UTF-8"?>
<root>
    <item type="weapon" code="W1" />
    <item type="armor" code="A1" />
    <item type="armor" />
</root>');

        $rootElement = new Element($domDocument->documentElement);

        $allCodes = $rootElement->getAll('item@code');
        $armorCodes = $rootElement->getAll("item[@type='armor']@code");

        $this->assertSame(['W1', 'A1'], $allCodes, 'Should return attribute values for each matching node that defines the attribute');
        $this->assertSame(['A1'], $armorCodes, 'Should skip matched nodes that do not define the requested attribute');
    }

    /**
     * Test splitXPathAttribute() method with various patterns including predicates and @ in brackets
     */
    public function test_split_x_path_attribute(): void
    {
        // Test 1: Simple path with attribute
        $result = $this->invokeMethod($this->testInstance, 'splitXPathAttribute', 'path@attr');
        $this->assertEquals(['path', 'attr'], $result, 'Should split simple path@attr correctly');

        // Test 2: Multi-level path with attribute
        $result = $this->invokeMethod($this->testInstance, 'splitXPathAttribute', 'path/to/element@attr');
        $this->assertEquals(['path/to/element', 'attr'], $result, 'Should split multi-level path@attr correctly');

        // Test 3: Path with predicate (ignores @ inside brackets)
        $result = $this->invokeMethod($this->testInstance, 'splitXPathAttribute', 'element[@condition]/child@attr');
        $this->assertEquals(['element[@condition]/child', 'attr'], $result, 'Should ignore @ inside brackets and split correctly');

        // Test 4: Path with no attribute
        $result = $this->invokeMethod($this->testInstance, 'splitXPathAttribute', 'path');
        $this->assertEquals(['path', null], $result, 'Should return path with null attribute when no @ present');

        // Test 5: Attribute alone (empty path)
        $result = $this->invokeMethod($this->testInstance, 'splitXPathAttribute', '@attr');
        $this->assertEquals(['', 'attr'], $result, 'Should return empty path and attribute when @attr alone');
    }

    /**
     * Test that get() initializes DOMXPath when missing
     */
    public function test_get_initializes_xpath(): void
    {
        $reflection = new \ReflectionClass($this->testInstance);
        $property = $reflection->getProperty('domXPath');

        $this->assertNull($property->getValue($this->testInstance), 'domXPath should start as null');

        $result = $this->testInstance->get('child');
        $this->assertInstanceOf(Element::class, $result, 'Should return Element from trait-based get()');

        $domXPath = $property->getValue($this->testInstance);
        $this->assertInstanceOf(DOMXPath::class, $domXPath, 'domXPath should be initialized after get()');
    }

    /**
     * Test XmlAccess trait behavior on RootDocument instance
     * Verifies that RootDocument and Element instances return the same results for identical path queries
     */
    public function test_get_on_root_document(): void
    {
        // Load a sample XML document using TestRootDocument
        $rootDocument = new TestRootDocument;
        $rootDocument->load(__DIR__.'/../Fixtures/xml/entityclassdefinition_sample.xml');

        // Test 1: Verify getDomDocument() returns DOMDocument instance (using reflection for protected method)
        $reflection = new \ReflectionClass($rootDocument);
        $method = $reflection->getMethod('getDomDocument');
        $domDocument = $method->invoke($rootDocument);

        $this->assertInstanceOf(DOMDocument::class, $domDocument, 'getDomDocument() should return DOMDocument instance');
        $this->assertSame($rootDocument, $domDocument, 'RootDocument is a DOMDocument, so should return itself');

        // Test 2: Compare RootDocument and Element results for path queries
        // Create an Element from the root document's document element
        $element = new Element($rootDocument->documentElement);

        // Test 2a: Get child element using path - both should return the same Element
        $rootResult = $rootDocument->get('defaultEditorColor');
        $elementResult = $element->get('defaultEditorColor');

        $this->assertInstanceOf(Element::class, $rootResult, 'RootDocument::get() should return Element for valid path');
        $this->assertInstanceOf(Element::class, $elementResult, 'Element::get() should return Element for valid path');
        $this->assertEquals(
            $rootResult->nodeName,
            $elementResult->nodeName,
            'RootDocument and Element should return same element for identical path'
        );

        // Test 2b: Get deep child element - both should return the same Element
        $rootDeepResult = $rootDocument->get('Components/EAPhaseActivePropComponentDef/capturedNotification');
        $elementDeepResult = $element->get('Components/EAPhaseActivePropComponentDef/capturedNotification');

        $this->assertInstanceOf(Element::class, $rootDeepResult, 'RootDocument::get() should return Element for deep path');
        $this->assertInstanceOf(Element::class, $elementDeepResult, 'Element::get() should return Element for deep path');
        $this->assertEquals(
            $rootDeepResult->nodeName,
            $elementDeepResult->nodeName,
            'RootDocument and Element should return same element for deep path'
        );

        // Test 2c: Get attribute value - both should return same value
        $rootAttr = $rootDocument->get('@Category');
        $elementAttr = $element->get('@Category');

        $this->assertEquals('EA', $rootAttr, 'RootDocument::get() should return attribute value');
        $this->assertEquals('EA', $elementAttr, 'Element::get() should return attribute value');
        $this->assertEquals(
            $rootAttr,
            $elementAttr,
            'RootDocument and Element should return same attribute value'
        );

        // Test 2d: Get attribute from nested element - both should return same value
        $rootNestedAttr = $rootDocument->get('defaultEditorColor@r');
        $elementNestedAttr = $element->get('defaultEditorColor@r');

        $this->assertEquals(1.0, $rootNestedAttr, 'RootDocument::get() should return nested attribute value');
        $this->assertEquals(1.0, $elementNestedAttr, 'Element::get() should return nested attribute value');
        $this->assertEquals(
            $rootNestedAttr,
            $elementNestedAttr,
            'RootDocument and Element should return same nested attribute value'
        );

        // Test 3: Verify non-existent path returns default value for both
        $default = 'default_value';
        $rootMissing = $rootDocument->get('nonexistent/path', $default);
        $elementMissing = $element->get('nonexistent/path', $default);

        $this->assertEquals($default, $rootMissing, 'RootDocument::get() should return default for non-existent path');
        $this->assertEquals($default, $elementMissing, 'Element::get() should return default for non-existent path');
    }

    /**
     * Test XmlAccess::getAll() behavior on RootDocument instance
     */
    public function test_get_all_on_root_document(): void
    {
        $rootDocument = new TestRootDocument;
        $rootDocument->load(__DIR__.'/../Fixtures/xml/entityclassdefinition_sample.xml');

        $element = new Element($rootDocument->documentElement);

        $rootElements = $rootDocument->getAll('Components/*');
        $elementElements = $element->getAll('Components/*');
        $rootAttributes = $rootDocument->getAll('defaultEditorColor@r');
        $elementAttributes = $element->getAll('defaultEditorColor@r');

        $this->assertContainsOnlyInstancesOf(Element::class, $rootElements, 'RootDocument::getAll() should return Element instances for element queries');
        $this->assertContainsOnlyInstancesOf(Element::class, $elementElements, 'Element::getAll() should return Element instances for element queries');
        $this->assertSame(
            array_map(static fn (Element $match): string => $match->nodeName, $elementElements),
            array_map(static fn (Element $match): string => $match->nodeName, $rootElements),
            'RootDocument and Element should return the same element matches'
        );
        $this->assertSame([1.0], $rootAttributes, 'RootDocument::getAll() should return all matching attribute values');
        $this->assertSame($rootAttributes, $elementAttributes, 'RootDocument and Element should return the same attribute matches');
    }
}

/**
 * Simple class that uses XmlAccess trait for testing purposes
 */
class XmlAccessTestClass
{
    use XmlAccess;

    public function __construct(
        protected DOMDocument $domDocument
    ) {}

    protected function getDomDocument(): DOMDocument
    {
        return $this->domDocument;
    }
}
