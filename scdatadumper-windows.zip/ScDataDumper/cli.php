#!/usr/bin/env php
<?php

// application.php

require __DIR__.'/vendor/autoload.php';

use Octfx\ScDataDumper\Commands\GenerateCache;
use Octfx\ScDataDumper\Commands\LoadBlueprints;
use Octfx\ScDataDumper\Commands\LoadCommodities;
use Octfx\ScDataDumper\Commands\LoadCommodityTradeLocations;
use Octfx\ScDataDumper\Commands\LoadContracts;
use Octfx\ScDataDumper\Commands\LoadData;
use Octfx\ScDataDumper\Commands\LoadFactions;
use Octfx\ScDataDumper\Commands\LoadItems;
use Octfx\ScDataDumper\Commands\LoadManufacturers;
use Octfx\ScDataDumper\Commands\LoadResources;
use Octfx\ScDataDumper\Commands\LoadStarmap;
use Octfx\ScDataDumper\Commands\LoadTags;
use Octfx\ScDataDumper\Commands\LoadTranslations;
use Octfx\ScDataDumper\Commands\LoadVehicles;
use Octfx\ScDataDumper\Commands\SchemaDiffCommand;
use Octfx\ScDataDumper\Commands\WikiSyncCommand;
use Symfony\Component\Console\Application;

$application = new Application('ScDataDumper', '1.0.0');

$application->addCommand(new GenerateCache);
$application->addCommand(new LoadItems);
$application->addCommand(new LoadBlueprints);
$application->addCommand(new LoadCommodities);
$application->addCommand(new LoadContracts);
$application->addCommand(new LoadVehicles);
$application->addCommand(new LoadFactions);
$application->addCommand(new LoadStarmap);
$application->addCommand(new LoadCommodityTradeLocations);
$application->addCommand(new LoadData);
$application->addCommand(new LoadTranslations);
$application->addCommand(new LoadManufacturers);
$application->addCommand(new LoadTags);
$application->addCommand(new LoadResources);
$application->addCommand(new SchemaDiffCommand);
$application->addCommand(new WikiSyncCommand);

$application->run();
