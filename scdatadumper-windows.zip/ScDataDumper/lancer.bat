@echo off
cd /d "%~dp0"
if not exist "C:\scdata\php\php.exe" (
  echo PHP introuvable : dezippe PHP dans C:\scdata\php
  pause
  exit /b 1
)
"C:\scdata\php\php.exe" -c "%~dp0php-windows.ini" cli.php load:data C:\scdata\import C:\scdata\export
echo.
echo Termine. Les fichiers sont dans C:\scdata\export
pause
