<?php

declare(strict_types=1);

namespace Octfx\ScDataDumper\Definitions\EntityClassDefinition\Components\SAttachableComponentParams\AttachDef;

use DOMDocument;
use Octfx\ScDataDumper\Helper\Element;
use Octfx\ScDataDumper\Services\ServiceFactory;

/**
 * @deprecated Eager hydration is deprecated. This hydrator will be removed once ECD component hydration is migrated into EntityClassDefinition.
 */
class Localization extends Element
{
    protected array $locales = [
        'english' => 'English',
        // 'german_(germany)' => 'German',
    ];

    protected array $keys = [
        '@Name',
        '@ShortName',
        '@Description',
    ];

    public function initialize(DOMDocument $document): void
    {
        if ($this->isInitialized()) {
            return;
        }

        parent::initialize($document);

        $t = ServiceFactory::getLocalizationService();

        foreach ($this->locales as $locale => $element) {
            if ($this->get($element)) {
                continue;
            }

            $translation = $document->createElement($element);

            $translation->setAttribute('Locale', $locale);

            foreach ($this->keys as $key) {
                $value = $this->get($key);
                $translatedValue = is_string($value) ? $t->getTranslation($value, $locale) : '';

                $translation->setAttribute(ltrim($key, '@'), $translatedValue);
            }

            if ($this->node->lastChild?->nodeName !== $element) {
                $this->node->appendChild($translation);
            }
        }
    }
}
