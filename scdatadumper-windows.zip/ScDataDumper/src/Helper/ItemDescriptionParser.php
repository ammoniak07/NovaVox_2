<?php

namespace Octfx\ScDataDumper\Helper;

class ItemDescriptionParser
{
    /**
     * Manufacturer name normalizations: description text => canonical name
     */
    private const MANUFACTURER_FIXES = [
        'Lighting Power Ltd.' => 'Lightning Power Ltd.',
        'MISC' => 'Musashi Industrial & Starflight Concern',
        'Nav-E7' => 'Nav-E7 Gadgets',
        'RSI' => 'Roberts Space Industries',
        'YORM' => 'Yorm',
    ];

    /**
     * Patterns that indicate placeholder descriptions
     */
    private const PLACEHOLDER_PATTERNS = [
        '/^<= PLACEHOLDER =>$/i',
        '/\[PH\]/i',
        '/\{PH\}/i',
        '/PLACEHOLDER/i',
    ];

    /**
     * Newline sequences to normalize to \n
     */
    private const NEWLINE_FORMATS = ["\r\n", "\r", '\n', '\\n'];

    /**
     * Unicode character replacements
     */
    private const UNICODE_REPLACEMENTS = [
        "\u{2018}" => "'",
        "\u{2019}" => "'",
        "\u{201C}" => '"',
        "\u{201D}" => '"',
        '`' => "'",
        "\u{00B4}" => "'",
        "\u{00A0}" => ' ',
        "\u{2013}" => '-',
        "\u{2014}" => '-',
    ];

    /**
     * Standard keywords extracted from SC item descriptions
     */
    public const array STANDARD_KEYWORDS = [
        'Action Figure',
        'All Charge Rates',
        'Area of Effect',
        'Armor',
        'Attachment Point',
        'Attachments',
        'Badge',
        'Battery Size',
        'Box',
        'Capacity',
        'Carrying Capacity',
        'Catastrophic Charge Rate',
        'Class',
        'Cluster Modifier',
        'Collection Point Radius',
        'Collection Throughput',
        'Core Compatibility',
        'Damage Reduction',
        'Damage Type',
        'Duration',
        'Effect',
        'Effective Range',
        'Effects',
        'Extraction Laser Power',
        'Extraction Rate',
        'Extraction Throughput',
        'Focus',
        'Grade',
        'HEI',
        'Inert Materials',
        'Instability',
        'Item Type',
        'Laser Instability',
        'Magazine Size',
        'Magnification',
        'Manufacturer',
        'Maximum Range',
        'Mining Laser Power',
        'Missiles',
        'Model',
        'Module Slots',
        'Module',
        'NDR',
        'Optimal Charge Rate',
        'Optimal Charge Window Rate',
        'Optimal Charge Window Size',
        'Optimal Charge Window',
        'Optimal Range',
        'Overcharge Rate',
        'Plant',
        'Plaque',
        'Poster',
        'Power Transfer',
        'Radiation Protection',
        'Radiation Scrub Rate',
        'Rate Of Fire',
        'Resistance',
        'Schematic',
        'Shatter Damage',
        'Size',
        'Spaceglobe',
        'Temp. Rating',
        'Throttle Responsiveness Delay',
        'Throttle Speed',
        'Tracking Signal',
        'Trophy',
        'Type',
        'Uses',
    ];

    /**
     * Parse structured data from item description text
     * Automatically applies manufacturer name corrections
     *
     * Extracts "Keyword: Value" patterns from descriptions formatted as:
     * "Manufacturer: AEGIS\nSize: 3\n\nActual item description text..."
     *
     * @param  string  $description  Raw description text from item data
     * @param  array|null  $keywords  Keywords to extract (null = use STANDARD_KEYWORDS)
     *                                Can be:
     *                                - Array of strings: ['Size', 'Grade'] => outputs same keys
     *                                - Associative array: ['Temp. Rating' => 'temp_rating'] => maps to custom keys
     * @param  array|null  $manufacturerFixes  Override for MANUFACTURER_FIXES (used by tests)
     * @return array {
     *
     * @type array|null $data Extracted key-value pairs (null if no data found)
     * @type string $description Cleaned description with data section removed
     *              }
     */
    public static function parse(string $description, ?array $keywords = null, ?array $manufacturerFixes = null): array
    {
        if ($keywords === null) {
            $keywords = self::STANDARD_KEYWORDS;
        }

        $description = self::normalizeText($description);

        $parts = explode("\n", $description);

        if (count($parts) === 1) {
            $parts = explode('\n', $parts[0]);
        }

        $withColon = collect($parts)->filter(function (string $part) {
            return preg_match('/\w:/u', $part) === 1;
        })->implode("\n");

        if (array_is_list($keywords)) {
            $keywords = array_combine($keywords, $keywords);
        }

        $keywords = self::filterRelevantKeywords($withColon, $keywords);

        if (empty($keywords)) {
            return [
                'description' => $description,
                'data' => null,
            ];
        }

        $match = preg_match_all(
            '/('.implode('|', array_keys($keywords)).'):[ \t]?(.+?)(?:\n|$)/mu',
            $withColon,
            $matches
        );

        if ($match === false || $match === 0) {
            if (self::isPlaceholder($description)) {
                return [
                    'description' => '',
                    'data' => null,
                ];
            }

            return [
                'description' => $description,
                'data' => null,
            ];
        }

        $out = [];
        for ($i = 0, $iMax = count($matches[1]); $i < $iMax; $i++) {
            if (isset($keywords[$matches[1][$i]])) {
                $value = self::sanitizeValue($matches[2][$i]);
                if ($value !== '') {
                    $out[$keywords[$matches[1][$i]]] = $value;
                }
            }
        }

        // manufacturer name corrections
        $manufacturerFixes ??= self::MANUFACTURER_FIXES;

        foreach (['manufacturer', 'Manufacturer'] as $key) {
            if (! empty($out[$key])) {
                $name = $out[$key];
                $fixed = $manufacturerFixes[$name] ?? array_find(
                    $manufacturerFixes,
                    fn ($value, $fixKey) => strcasecmp($fixKey, $name) === 0
                );
                if ($fixed !== null) {
                    $out[$key] = $fixed;
                }
            }
        }

        return [
            'description' => self::getCleanText($description, array_keys($out)),
            'data' => $out ?: null,
        ];
    }

    /**
     * Extract clean description text, removing data section
     *
     * @param  string  $description  Raw description text
     * @param  array<string>  $matchedKeywords  Keywords that were actually matched and extracted
     * @return string Description with "Keyword: Value" section removed
     */
    private static function getCleanText(string $description, array $matchedKeywords): string
    {
        $description = self::normalizeText($description);

        // If no keywords were matched, the entire description is prose
        if (empty($matchedKeywords)) {
            return $description;
        }

        $exploded = explode("\n\n", $description);

        if (count($exploded) === 1) {
            $exploded = explode('\n\n', $exploded[0]);
        }

        // Build a regex from the actual matched keywords to strip those data lines
        $escapedKeywords = array_map(static fn (string $kw) => preg_quote($kw, '/'), $matchedKeywords);
        $keywordPattern = '/^('.implode('|', $escapedKeywords).')\s*[：:]/m';

        // General data-line pattern: catches unknown keywords like "G-Force Tolerance"
        // Pattern: line starts with short uppercase label (letters, spaces, dots, hyphens)
        // followed by colon and a non-empty value. Max label length ~35 chars.
        $generalDataPattern = '/^[A-Z\d][A-Za-z\s.\-]{0,33}[：:]\s*\S/m';

        $cleaned = [];

        foreach ($exploded as $part) {
            $lines = explode("\n", $part);
            $prose = array_filter($lines, static function (string $line) use ($keywordPattern, $generalDataPattern) {
                // Strip if it matches a known keyword OR looks like a general data line
                return preg_match($keywordPattern, $line) !== 1
                    && preg_match($generalDataPattern, $line) !== 1;
            });
            $prose = implode("\n", $prose);

            if (trim($prose) !== '') {
                $cleaned[] = $prose;
            }
        }

        return trim(implode("\n\n", $cleaned));
    }

    /**
     * Pre-filter keywords to only those likely present in description
     * Reduces regex complexity for descriptions with few keywords
     *
     * @param  string  $description  Description text to search
     * @param  array  $keywords  All available keywords
     * @return array Filtered keywords that appear in description
     */
    private static function filterRelevantKeywords(string $description, array $keywords): array
    {
        if (count($keywords) < 10) {
            return $keywords;
        }

        $relevant = array_filter($keywords, static function ($key) use ($description) {
            return stripos($description, $key) !== false;
        }, ARRAY_FILTER_USE_KEY);

        return $relevant ?: $keywords;
    }

    /**
     * Sanitize extracted value
     * Handles trailing punctuation, excess whitespace, invalid chars
     *
     * @param  string  $value  Raw value from regex extraction
     * @return string Sanitized value
     */
    private static function sanitizeValue(string $value): string
    {
        $value = trim($value);

        $value = rtrim($value, '.,;');

        $value = preg_replace('/\s+/', ' ', $value);

        $value = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $value);

        return trim($value);
    }

    /**
     * Check if description is a placeholder
     *
     * @param  string  $description  Description text to check
     */
    private static function isPlaceholder(string $description): bool
    {
        return array_any(self::PLACEHOLDER_PATTERNS, fn ($pattern) => preg_match($pattern, $description));
    }

    /**
     * Normalize description text
     * - Converts all newline formats to \n
     * - Normalizes Unicode quotes, dashes, and spaces
     * - Collapses excessive whitespace
     */
    private static function normalizeText(string $description): string
    {
        foreach (self::NEWLINE_FORMATS as $format) {
            $description = str_replace($format, "\n", $description);
        }

        // Normalize double-escaped newlines with spaces (\\n \\n -> \n\n)
        $description = preg_replace('/\\\n\s+\\\n/', "\n\n", $description);

        // Normalize literal whitespace-only lines between newlines ("\n \n", "\n\xa0\n" -> "\n\n")
        $description = preg_replace('/\n[ \t\x{00A0}]+\n/u', "\n\n", $description);

        $description = str_replace(
            array_keys(self::UNICODE_REPLACEMENTS),
            array_values(self::UNICODE_REPLACEMENTS),
            $description
        );

        $description = preg_replace('/[ \t]+/', ' ', $description);

        return trim($description);
    }
}
