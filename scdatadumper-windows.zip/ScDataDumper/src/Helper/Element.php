<?php

namespace Octfx\ScDataDumper\Helper;

use DOMDocument;
use DOMException;
use DOMNode;
use DOMXPath;
use Generator;
use Octfx\ScDataDumper\Concerns\NormalizesValues;
use Octfx\ScDataDumper\DocumentTypes\RootDocument;
use Octfx\ScDataDumper\Services\ServiceFactory;
use RuntimeException;
use WeakMap;

class Element
{
    use NormalizesValues;
    use XmlAccess;

    /**
     * Tracks which DOMNodes have already been initialized.
     * WeakMap is used so entries are freed when the DOMDocument is discarded.
     */
    protected static ?WeakMap $initialized = null;

    /**
     * Shared DOMXPath per DOMDocument
     */
    private static ?WeakMap $xPathCache = null;

    public function __construct(protected readonly DOMNode $node)
    {
        $doc = $this->getDomDocument();

        self::$xPathCache ??= new WeakMap;

        if (! isset(self::$xPathCache[$doc])) {
            self::$xPathCache[$doc] = new DOMXPath($doc);
        }

        $this->domXPath = self::$xPathCache[$doc];
    }

    protected function getDomDocument(): DOMDocument
    {
        return $this->node->ownerDocument ?? $this->node;
    }

    /**
     * Adds the current node path to the list of processed nodes
     */
    public function initialize(DOMDocument $document): void
    {
        self::$initialized ??= new WeakMap;
        self::$initialized[$this->node] = true;
    }

    public function getNode(): DOMNode
    {
        return $this->node;
    }

    /**
     * Appends `$import` after `$this->node`
     *
     * @param  string|null  $elementName  Optional XML Tag name that holds the content of $import
     *                                    This is useful when importing whole XML files as without this argument the root tag of the imported document is used.
     *                                    For manufacturers this would be (example) `<Manufacturer.APAR>` instead of `<Manufacturer>`
     */
    protected function appendNode(DOMDocument|DOMNode $document, ?DOMDocument $import, ?string $elementName = null): void
    {
        if (! $import) {
            return;
        }

        $importedNode = $document->importNode($import->documentElement, true);

        if ($importedNode === false) {
            throw new RuntimeException('Failed to import node');
        }

        if ($elementName) {
            try {
                $renamedElement = $document->createElement($elementName);
                $renamedElement->append(...$importedNode->childNodes);

                if ($import->firstChild?->attributes) {
                    foreach ($import->firstChild->attributes as $name => $attribute) {
                        $renamedElement->setAttribute($name, $attribute->nodeValue);
                    }
                }

                $this->node->appendChild($renamedElement);
            } catch (DOMException $e) {

            }
        } else {
            $this->node->appendChild($importedNode);
        }
    }

    protected function hydrateFoundryReference(
        DOMDocument $document,
        string $referencePath,
        string $childNodeName,
        ?RootDocument $record
    ): void {
        $reference = $this->get($referencePath);

        if (! is_string($reference) || $reference === '' || $this->get($childNodeName.'@__ref') === $reference) {
            return;
        }

        if ($record !== null) {
            $this->appendNode($document, $record, $childNodeName);
        }
    }

    /**
     * Turns Element Attributes into an array
     */
    public function attributesToArray(?array $ignore = [], ?bool $pascalCase = false): array
    {
        $attributes = [];

        if ($pascalCase) {
            $ignore = array_map([$this, 'toPascalCase'], $ignore);
        }

        foreach ($this->node->attributes as $attribute) {
            if (! $attribute || in_array($attribute->nodeName, ['__type', '__polymorphicType'], true)) {
                continue;
            }

            $name = $attribute->nodeName;
            $value = $attribute->nodeValue;

            if ($pascalCase) {
                $name = $this->toPascalCase($name);
            }

            if (! in_array($name, $ignore, true)) {
                if (is_numeric($value)) {
                    $attributes[$name] = (float) $value;
                } elseif (str_starts_with((string) $value, '@')) {
                    // Someone accidentally put the description in the name attribute
                    if ($name === 'Name' && str_contains($value, '_Desc_')) {
                        $value = str_replace('_Desc_', '_Name_', $value);
                    }

                    $attributes[$name] = ServiceFactory::getLocalizationService()->translateValue((string) $value) ?? (string) $value;
                    $attributes['__'.$name] = (string) $value;
                } else {
                    $attributes[$name] = (string) $value;
                }
            }
        }

        return $attributes;
    }

    /**
     * Checks if a child element or attribute exists relative to this element.
     *
     * @param  string  $key  XPath-like path scoped to this element (e.g. 'child/grandchild@attr')
     * @param  string|null  $elementName  Expected element name; defaults to the last segment of $key
     */
    public function has(string $key, ?string $elementName = null): bool
    {
        if (str_contains($key, '.')) {
            throw new RuntimeException('Element key contains invalid format');
        }

        $parts = explode('/', $key);
        $elementName = $elementName ?? array_pop($parts);

        $obj = $this->get($key, $key);

        if ($obj === null) {
            return false;
        }

        if (! is_object($obj)) {
            return $obj !== $key;
        }

        return $obj instanceof self && $obj->nodeName === $elementName;
    }

    public function __call(string $name, array $arguments)
    {
        return $this->node->{$name}(...$arguments);
    }

    public function __get(string $name)
    {
        return $this->node->{$name};
    }

    /**
     * Returns all child elements and wraps it in DOMElementProxy
     *
     * @return Generator<int, self, mixed, void>
     */
    public function children(): Generator
    {
        foreach ($this->node->childNodes as $child) {
            if ($child->nodeType !== XML_ELEMENT_NODE) {
                continue;
            }

            yield new self($child);
        }
    }

    /**
     * Checks if the current node has already been processed
     */
    protected function isInitialized(): bool
    {
        return self::$initialized?->offsetExists($this->node) ?? false;
    }
}
