<?php

namespace Octfx\ScDataDumper\Services;

use JsonException;
use Octfx\ScDataDumper\DocumentTypes\Recovery\ItemRecoveryConfigurationParams;
use Octfx\ScDataDumper\Services\Resource\ResourceService;
use RuntimeException;

final class ServiceFactory
{
    private const array SC_DATA_PATH_INDEPENDENT = [
        'ItemClassifierService',
        'ContractLocationResolver',
        'MissionLocationStarmapResolver',
        'DataOverrideService',
    ];

    private static bool $initialized = false;

    private static ?string $activeScDataPath = null;

    private static ?string $activeJsonOutPath = null;

    /**
     * @var BaseService[]
     */
    private static array $services = [];

    public function __construct(
        private readonly string $scDataPath,
        private readonly ?string $jsonOutPath = null,
    ) {}

    /**
     * @throws JsonException
     */
    public function initialize(): void
    {
        $jsonOutPath = $this->jsonOutPath ?? $this->scDataPath;

        if (
            self::$initialized
            && self::$activeScDataPath === $this->scDataPath
            && self::$activeJsonOutPath === $jsonOutPath
        ) {
            return;
        }

        if (
            self::$activeScDataPath !== null
            && (
                self::$activeScDataPath !== $this->scDataPath
                || self::$activeJsonOutPath !== $jsonOutPath
            )
        ) {
            self::$services = [];
        }

        self::$activeScDataPath = $this->scDataPath;
        self::$activeJsonOutPath = $jsonOutPath;

        self::$initialized = true;
    }

    public static function isInitialized(): bool
    {
        return self::$initialized;
    }

    public static function getActiveScDataPath(): ?string
    {
        return self::$activeScDataPath;
    }

    public static function reset(): void
    {
        self::$initialized = false;
        self::$activeScDataPath = null;
        self::$activeJsonOutPath = null;
        self::$services = [];

        BaseService::resetSharedState();
        BlueprintService::resetDocumentCache();
        ContractGeneratorService::resetDocumentCache();
        MissionBrokerService::resetDocumentCache();
        ItemService::resetDocumentCache();
        VehicleService::resetDocumentCache();
        LoadoutFileService::resetDocumentCache();
        ItemClassifierService::resetCache();
        ManufacturerService::resetDocumentCache();
        ManufacturerService::resetDataOverrideCache();
        DataOverrideService::reset();
    }

    public static function getInventoryContainerService(): InventoryContainerService
    {
        return self::getService('InventoryContainerService');
    }

    public static function getManufacturerService(): ManufacturerService
    {
        return self::getService('ManufacturerService');
    }

    public static function getItemService(): ItemService
    {
        return self::getService('ItemService');
    }

    public static function getLocalizationService(): LocalizationService
    {
        return self::getService('LocalizationService');
    }

    public static function getBlueprintService(): BlueprintService
    {
        return self::getService('BlueprintService');
    }

    public static function getTagDatabaseService(): TagDatabaseService
    {
        return self::getService('TagDatabaseService');
    }

    public static function getItemClassifierService(): ItemClassifierService
    {
        return self::getService('ItemClassifierService');
    }

    public static function getAmmoParamsService(): AmmoParamsService
    {
        return self::getService('AmmoParamsService');
    }

    public static function getVehicleService(): VehicleService
    {
        return self::getService('VehicleService');
    }

    public static function getContractGeneratorService(): ContractGeneratorService
    {
        return self::getService('ContractGeneratorService');
    }

    public static function getMissionBrokerService(): MissionBrokerService
    {
        return self::getService('MissionBrokerService');
    }

    public static function getFoundryLookupService(): FoundryLookupService
    {
        return self::getService('FoundryLookupService');
    }

    public static function getResourceService(): ResourceService
    {
        return self::getService('ResourceService');
    }

    public static function getStarmapParentResolver(): StarmapParentResolver
    {
        return self::getService('StarmapParentResolver');
    }

    public static function getLoadoutFileService(): LoadoutFileService
    {
        return self::getService('LoadoutFileService');
    }

    public static function getContractLocationResolver(): ContractLocationResolver
    {
        return self::getService('ContractLocationResolver');
    }

    public static function getMissionLocationStarmapResolver(): MissionLocationStarmapResolver
    {
        return self::getService('MissionLocationStarmapResolver');
    }

    public static function getDataOverrideService(): DataOverrideService
    {
        return self::getService('DataOverrideService');
    }

    public static function getShipPoolResolver(): ShipPoolResolver
    {
        return self::getService('ShipPoolResolver');
    }

    public static function getItemRecoveryConfiguration(): ?ItemRecoveryConfigurationParams
    {
        return self::getFoundryLookupService()->getItemRecoveryConfiguration();
    }

    private static function getService(string $serviceName): mixed
    {
        if (! self::$initialized) {
            throw new RuntimeException('Service factory is not initialized');
        }

        self::bootService($serviceName);

        return self::$services[$serviceName];
    }

    private static function bootService(string $serviceName): void
    {
        if (isset(self::$services[$serviceName])) {
            return;
        }

        if (! in_array($serviceName, self::SC_DATA_PATH_INDEPENDENT, true) && self::$activeScDataPath === null) {
            throw new RuntimeException('Service factory path is not initialized');
        }

        $service = match ($serviceName) {
            'InventoryContainerService' => new InventoryContainerService(self::$activeScDataPath),
            'ManufacturerService' => new ManufacturerService(self::$activeScDataPath),
            'ItemService' => new ItemService(self::$activeScDataPath),
            'BlueprintService' => new BlueprintService(self::$activeScDataPath),
            'ContractGeneratorService' => new ContractGeneratorService(self::$activeScDataPath),
            'MissionBrokerService' => new MissionBrokerService(self::$activeScDataPath),
            'LocalizationService' => new LocalizationService(self::$activeScDataPath),
            'ItemClassifierService' => new ItemClassifierService,
            'TagDatabaseService' => new TagDatabaseService(self::$activeScDataPath),
            'AmmoParamsService' => new AmmoParamsService(self::$activeScDataPath),
            'VehicleService' => new VehicleService(self::$activeScDataPath),
            'FoundryLookupService' => new FoundryLookupService(self::$activeScDataPath),
            'ResourceService' => new ResourceService(self::$activeJsonOutPath, self::$activeScDataPath),
            'StarmapParentResolver' => new StarmapParentResolver(self::$activeScDataPath),
            'LoadoutFileService' => new LoadoutFileService(self::$activeScDataPath),
            'ContractLocationResolver' => new ContractLocationResolver,
            'MissionLocationStarmapResolver' => new MissionLocationStarmapResolver,
            'DataOverrideService' => new DataOverrideService,
            'ShipPoolResolver' => new ShipPoolResolver(self::$activeScDataPath),
            default => throw new RuntimeException('Unknown service: '.$serviceName),
        };

        if ($service instanceof BaseService) {
            $service->initialize();
        }

        self::$services[$serviceName] = $service;
    }
}
