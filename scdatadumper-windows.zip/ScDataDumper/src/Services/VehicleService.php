<?php

namespace Octfx\ScDataDumper\Services;

use DOMDocument;
use DOMElement;
use DOMXPath;
use Generator;
use JsonException;
use Octfx\ScDataDumper\DocumentTypes\Vehicle;
use Octfx\ScDataDumper\DocumentTypes\VehicleDefinition;
use Octfx\ScDataDumper\Helper\VehicleWrapper;
use Octfx\ScDataDumper\Services\Vehicle\LoadoutBuilder;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use RuntimeException;
use SplFileInfo;

final class VehicleService extends BaseService
{
    private array $vehicles;

    /**
     * LRU document cache keyed by file path or composite key.
     *
     * @var array<string, VehicleDefinition|Vehicle>
     */
    protected static array $documentCache = [];

    private const CACHE_LIMIT = 200;

    public static function resetDocumentCache(): void
    {
        self::$documentCache = [];
    }

    private array $implementations = [];

    // Avoid files containing tags
    private array $avoids = [
        'active1',
        'advocacy',
        'ai',
        'aiship',
        'bombless',
        'bounty',
        'c19b',
        'citizencon',
        'civ',
        'comms',
        'crim',
        'derelict',
        'drone',
        'drug',
        'dummy',
        'eaobjectivedestructable',
        'featuretest',
        'fleetweek',
        'fw22nfz',
        'hijacked',
        'human',
        'indestructible',
        'kopion',
        'microtech',
        'mlhm1',
        'modifiers',
        'nocrimesagainst',
        'nointerior',
        'npc',
        'outlaw',
        'outlaws',
        'piano',
        'player',
        'pu',
        'qig',
        's3bombs',
        's42',
        'securitynetwork',
        'shields',
        'shipshowdown',
        'shubin',
        'swarm',
        'template',
        'tow',
        'tutorial',
        'uee',
        'unmanned',
        'wreck',
    ];

    // Avoid these file suffixes
    private array $avoidSuffixes = [
        // '_rn',
        '_ac_engineer',
        '_cci2953',
        '_cinematic_only',
        '_ea_pir',
        '_fw22nfz',
        '_mfd',
        '_prison',
        '_pir_package',
        '_temp',
        '_test',
        '_instanced',
    ];

    public function count(): int
    {
        return count($this->vehicles);
    }

    /**
     * @throws JsonException
     */
    public function initialize(): void
    {
        $this->loadImplementations();
        $items = json_decode(file_get_contents($this->classToPathMapPath), true, 512, JSON_THROW_ON_ERROR)['EntityClassDefinition'] ?? [];

        $items = array_filter($items, static fn (string $path) => str_contains($path, 'entities'.DIRECTORY_SEPARATOR.'spaceships') || str_contains($path, 'entities'.DIRECTORY_SEPARATOR.'groundvehicles') || str_contains($path, 'actor'.DIRECTORY_SEPARATOR.'actors'));
        $items = array_filter($items, function (string $path): bool {
            $name = basename($path, '.xml');
            $parts = array_map('strtolower', explode('_', $name));

            return ! array_reduce($parts, fn ($carry, $cur) => $carry || in_array(strtolower($cur), $this->avoids, true), false);
        });

        $items = array_filter($items, function (string $path): bool {
            $name = basename($path, '.xml');

            return ! array_reduce($this->avoidSuffixes, static fn ($carry, $cur) => $carry || str_ends_with(strtolower($name), strtolower($cur)), false);
        });

        // Testing
        // $items = array_filter($items, static fn (string $path) => str_contains($path, 'aegs_avenger'));

        $this->vehicles = $items;
    }

    public function iterator(?string $filter = null): Generator
    {
        foreach ($this->vehicles as $path) {
            if ($filter && stripos($path, $filter) === false) {
                continue;
            }

            $vehicle = $this->load($path);
            if ($vehicle === null) {
                continue;
            }

            yield $vehicle;
        }
    }

    public function load(string $filePath): ?VehicleWrapper
    {
        if (! file_exists($filePath)) {
            throw new RuntimeException(sprintf('File %s does not exist or is not readable.', $filePath));
        }

        $vehicle = self::cacheGet(self::$documentCache, $filePath);
        if (! $vehicle instanceof VehicleDefinition) {
            $vehicle = new VehicleDefinition;
            $vehicle->load($filePath);
            self::cachePut(self::$documentCache, $filePath, $vehicle, self::CACHE_LIMIT);
        }

        $implementation = $vehicle->get('Components/VehicleComponentParams@vehicleDefinition');

        $doc = null;
        if ($implementation !== null) {
            $fileName = explode('/', $implementation);
            $fileName = array_pop($fileName);

            $implementation = $this->implementations[strtolower($fileName)];
            $modification = $vehicle->get('Components/VehicleComponentParams@modification');

            $doc = $this->parseVehicle($implementation, $modification);

            $doc->initXPath();
        } elseif ($vehicle->getAttachType() !== 'NOITEM_Vehicle') {
            return null;
        }

        $manualLoadout = $vehicle->get('Components/SEntityComponentDefaultLoadoutParams/loadout/SItemPortLoadoutManualParams');

        $loadout = [];
        if ($manualLoadout) {
            $loadoutBuilder = new LoadoutBuilder(
                ServiceFactory::getItemService(),
                new ItemClassifierService
            );
            $loadout = $loadoutBuilder->build($manualLoadout);
        }

        $vehicle->initXPath();

        return new VehicleWrapper(
            $doc,
            $vehicle,
            $loadout
        );
    }

    private function parseVehicle(string $vehiclePath, ?string $modificationName): Vehicle
    {
        $cacheKey = $vehiclePath.'|'.$modificationName;

        $doc = self::cacheGet(self::$documentCache, $cacheKey);
        if ($doc instanceof Vehicle) {
            return $doc;
        }

        $doc = new Vehicle;
        $doc->load($vehiclePath);

        if ($modificationName !== null && trim($modificationName) !== '') {
            $this->processPatchFile($doc, $modificationName, $vehiclePath);
            $this->processModificationElems($doc, $modificationName);
        }

        self::cachePut(self::$documentCache, $cacheKey, $doc, self::CACHE_LIMIT);

        return $doc;
    }

    private function processPatchFile($doc, $modificationName, $vehiclePath): void
    {
        $xpath = new DOMXPath($doc);
        $modificationNode = $xpath->query("//Modifications/Modification[@name='$modificationName']")->item(0);
        $patchFile = $modificationNode?->getAttribute('patchFile');

        if (empty($patchFile)) {
            return;
        }

        $patchFilename = sprintf(
            '%s%sModifications%s%s.xml',
            pathinfo($vehiclePath, PATHINFO_DIRNAME),
            DIRECTORY_SEPARATOR,
            DIRECTORY_SEPARATOR,
            str_replace('/', DIRECTORY_SEPARATOR, pathinfo($patchFile, PATHINFO_FILENAME))
        );

        if (! file_exists($patchFilename)) {
            return;
        }

        $patchDoc = new DOMDocument;
        $patchDoc->load($patchFilename, LIBXML_NOCDATA | LIBXML_NOBLANKS | LIBXML_COMPACT);

        /** @var DOMElement $patchNode */
        foreach ($patchDoc->firstChild->childNodes as $patchNode) {
            if ($patchNode->nodeType !== XML_ELEMENT_NODE) {
                continue;
            }

            $id = $patchNode->getAttribute('id');
            if (empty($id)) {
                echo "Can't load modifications for {$patchNode->nodeName} - there is no id attribute".PHP_EOL;

                continue;
            }

            $nodes = $xpath->query("//*[@id='$id']");
            /** @var DOMElement $node */
            foreach ($nodes as $node) {
                $clonedNode = $doc->importNode($patchNode, true);
                $node->replaceWith($clonedNode);
            }
        }
    }

    private function processModificationElems($doc, $modificationName): void
    {
        $xpath = new DOMXPath($doc);
        $elems = $xpath->query("//Modifications/Modification[@name='$modificationName']/Elems/Elem");

        foreach ($elems as $elem) {
            $idRef = $elem->getAttribute('idRef');
            $attrName = $elem->getAttribute('name');
            $attrValue = $elem->getAttribute('value');

            $nodes = $xpath->query("//*[@id='$idRef']");
            /** @var DOMElement $node */
            foreach ($nodes as $node) {
                $attr = $node->getAttributeNode($attrName);
                if ($attr === null || $attr === false) {
                    $attr = $doc->createAttribute($attrName);
                    $node->appendChild($attr);
                }
                $attr->value = $attrValue;
            }
        }
    }

    private function loadImplementations(): void
    {
        $implementationsPath = [
            $this->scDataDir,
            'Data',
            'Scripts',
            'Entities',
            'Vehicles',
            'Implementations',
            'Xml',
        ];
        $implementationsPath = implode(DIRECTORY_SEPARATOR, $implementationsPath);

        if (! is_dir($implementationsPath)) {
            return;
        }

        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($implementationsPath));

        $implementations = [];

        /** @var SplFileInfo $file */
        foreach ($iterator as $file) {
            if (
                $file->isFile() && $file->getExtension() === 'xml'
                // Modifications are not real vehicles + collides with vanduul stinger
                && ! str_contains($file->getPathname(), DIRECTORY_SEPARATOR.'Modifications'.DIRECTORY_SEPARATOR)
            ) {
                $parts = explode('/', $file->getBasename());
                $name = array_pop($parts);

                $implementations[strtolower($name)] = $file->getPathname();
            }
        }

        $this->implementations = $implementations;
    }
}
