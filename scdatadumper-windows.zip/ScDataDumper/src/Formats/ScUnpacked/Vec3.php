<?php

namespace Octfx\ScDataDumper\Formats\ScUnpacked;

use DOMNode;
use Octfx\ScDataDumper\DocumentTypes\RootDocument;
use Octfx\ScDataDumper\Formats\BaseFormat;
use Octfx\ScDataDumper\Helper\Element;

final class Vec3 extends BaseFormat
{
    public function __construct(DOMNode|Element|RootDocument|null $item, private readonly ?array $names = [])
    {
        parent::__construct($item);
    }

    public function toArray(): ?array
    {
        if (! $this->canTransform()) {
            return null;
        }

        return [
            $this->names['x'] ?? 'x' => $this->get('@x'),
            $this->names['y'] ?? 'y' => $this->get('@y'),
            $this->names['z'] ?? 'z' => $this->get('@z'),
        ];
    }

    public function canTransform(): bool
    {
        if ($this->item === null) {
            return false;
        }

        if ($this->item->nodeName === 'Vec3' || $this->item->get('@__type') === 'Vec3') {
            return true;
        }

        return $this->item->get('@x') !== null
            && $this->item->get('@y') !== null
            && $this->item->get('@z') !== null;
    }
}
