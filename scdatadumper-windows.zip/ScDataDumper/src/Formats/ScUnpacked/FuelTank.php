<?php

namespace Octfx\ScDataDumper\Formats\ScUnpacked;

use Octfx\ScDataDumper\DocumentTypes\EntityClassDefinition;
use Octfx\ScDataDumper\DocumentTypes\RootDocument;
use Octfx\ScDataDumper\Formats\BaseFormat;
use Octfx\ScDataDumper\Helper\Element;

/**
 * @extends BaseFormat<EntityClassDefinition>
 */
final class FuelTank extends BaseFormat
{
    protected ?string $elementKey = 'Components/ResourceContainer';

    public function __construct(RootDocument|Element $element, private readonly string $type = 'FuelTank')
    {
        parent::__construct($element);
    }

    public function toArray(): ?array
    {
        if (! $this->canTransform()) {
            return null;
        }

        $container = $this->get();

        $tankParams = $this->item?->get('Components/SCItemFuelTankParams');

        return [
            'Capacity' => (float) Item::convertToScu($container?->get('capacity')),
            'HydrogenMaxFlowMultiplier' => (float) ($tankParams?->get('@hydrogenMaxFlowMultiplier') ?? 1),
            'QuantumMaxFlowMultiplier' => (float) ($tankParams?->get('@quantumMaxFlowMultiplier') ?? 1),
        ];
    }

    public function canTransform(): bool
    {
        return parent::canTransform() && $this->item?->getAttachType() === $this->type;
    }
}
