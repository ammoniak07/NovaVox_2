<?php

namespace Octfx\ScDataDumper\Formats\ScUnpacked;

use Exception;
use Illuminate\Support\Arr;
use Octfx\ScDataDumper\Formats\BaseFormat;
use Octfx\ScDataDumper\Helper\Element;
use Octfx\ScDataDumper\Services\ServiceFactory;

/**
 * Shared weapon logic (damage, modes, magazine, etc.) for both personal and vehicle weapons.
 */
abstract class AbstractWeapon extends BaseFormat
{
    protected ?string $elementKey = 'Components/SCItemWeaponComponentParams';

    /**
     * Six-key damage map pulled from a fire mode via an attribute prefix (Alpha, Dps, ...).
     *
     * @param  array<string, mixed>  $mode
     * @return array<string, mixed>
     */
    protected function damageMapByMode(array $mode, string $prefix): array
    {
        $result = [];

        foreach (self::$resistanceKeys as $key) {
            $result[$key] = Arr::get($mode, $prefix.$key);
        }

        return $result;
    }

    protected function buildBaseWeaponArray(): array
    {
        $weapon = $this->get();

        $ammunition = new Ammunition($this->item);
        $ammunitionArray = $ammunition->toArray();

        $magazine = $this->buildMagazine();
        $capacity = is_array($ammunitionArray) ? ($ammunitionArray['Capacity'] ?? null) : null;
        if ($capacity === null && is_array($magazine)) {
            $capacity = $magazine['MaxAmmoCount'] ?? null;
        }

        $out = [
            'Size' => $this->item->getAttachSize(),
            'WeaponType' => $this->item->getAttachType(),
            'WeaponClass' => $this->item->getAttachSubType(),
            'EffectiveRange' => $this->resolveEffectiveRange($weapon, $ammunitionArray),
            'RateOfFire' => null,
            'Capacity' => $capacity,
            'Magazine' => $magazine,
            // 'Ammunition' => $ammunitionArray, // Deprecated: Use stdItem.Ammunition
            'Attachments' => $this->buildAttachments(),
            'Modes' => [],
            'Consumption' => new WeaponConsumption($weapon)->toArray(),
            'Knife' => new MeleeWeapon($this->item),
        ];

        foreach ($weapon->get('fireActions')?->children() as $action) {
            foreach ($this->expandFireAction($action) as $fireAction) {
                $mode = new WeaponMode($fireAction);
                if (! $mode->canTransform()) {
                    continue;
                }

                $mode = $mode->toArray();

                $isBeam = in_array($fireAction->nodeName, [
                    'SWeaponActionFireBeamParams',
                    'SWeaponActionFireHealingBeamParams',
                    'SWeaponActionFireSalvageRepairParams',
                    'SWeaponActionGatheringBeamParams',
                    'SWeaponActionFireTractorBeamParams',
                ], true);
                $chargeContext = ['Timings' => [], 'Modifier' => []];
                $capacity = $out['Capacity'] ?? ($ammunitionArray['Capacity'] ?? null);

                if ($isBeam) {
                    if ($fireAction->nodeName === 'SWeaponActionFireBeamParams') {
                        $damage = $this->calculateBeamDamage($fireAction);
                        $mode['DamagePerShot'] = 0;
                        $mode['DamagePerSecond'] = $this->roundStat($damage['Total']);
                        $mode['Alpha'] = 0;
                        $mode['Dps'] = $mode['DamagePerSecond'];

                        if ($capacity !== null) {
                            $mode['MaxDamagePerMagazine'] = $this->roundStat($damage['Total'] * (float) $capacity);
                        }

                        foreach ($damage['ByType'] as $type => $value) {
                            $mode['Dps'.$type] = $this->roundStat($value);
                        }

                        foreach ($damage['ByType'] as $type => $value) {
                            $mode['Alpha'.$type] = 0;
                        }
                    }
                } else {
                    $launchParams = $this->extractLauncherParams($fireAction);
                    $chargeContext = $this->extractChargeContext($fireAction);
                    $damageMultiplier = $this->extractDamageMultiplier($launchParams, $chargeContext['Modifier']);

                    $pellets = (float) ($mode['PelletsPerShot'] ?? 0);

                    // Fire actions carrying projectileType="Secondary" draw their damage from the magazine's secondary ammo record
                    $modeAmmunition = $ammunitionArray;
                    if ($launchParams?->get('@projectileType') === 'Secondary') {
                        $modeAmmunition = new Ammunition($this->item, secondary: true)->toArray() ?? $ammunitionArray;
                    }

                    $damage = $this->calculateDamage($modeAmmunition, $pellets, $damageMultiplier);

                    $rpm = $this->calculateEffectiveRpm($mode['RoundsPerMinute'] ?? null, $fireAction, $chargeContext['Modifier']);
                    if ($rpm !== null) {
                        $mode['RoundsPerMinute'] = $this->roundStat($rpm);
                    }

                    $mode['DamagePerShot'] = $this->roundStat($damage['Total'], 3);
                    $mode['DamagePerSecond'] = $this->roundStat($this->calculateDamagePerSecond($damage['Total'], $mode['RoundsPerMinute'] ?? null));
                    $mode['Alpha'] = $this->roundStat($damage['Total']);
                    $mode['Dps'] = $mode['DamagePerSecond'];

                    if ($capacity !== null) {
                        $mode['MaxDamagePerMagazine'] = $this->roundStat($damage['Total'] * (float) $capacity);
                    }

                    foreach ($this->buildDamagePerSecondByType($damage['ByType'], $mode['RoundsPerMinute'] ?? null) as $type => $value) {
                        $mode['Dps'.$type] = $this->roundStat($value);
                    }

                    foreach ($damage['ByType'] as $type => $value) {
                        $mode['Alpha'.$type] = $this->roundStat($value, 3);
                    }
                }

                $spread = $this->extractSpread($fireAction);
                if ($spread !== []) {
                    $mode['Spread'] = $spread;
                    $mode['AdsSpread'] = $this->extractAdsSpread($weapon, $spread);
                }

                $spin = $this->extractSpinTimes($fireAction);
                if ($spin !== []) {
                    $mode['BarrelSpinTime'] = $spin;
                }

                if ($chargeContext['Timings'] !== []) {
                    $mode['Charge'] = $chargeContext['Timings'];
                }

                if ($chargeContext['Modifier'] !== []) {
                    $mode['ChargeModifier'] = $chargeContext['Modifier'];
                }

                $out['RateOfFire'] ??= $mode['RoundsPerMinute'] ?? null;

                $out['Modes'][] = $mode;
            }
        }

        $consumption = $out['Consumption'];
        if (empty($out['Capacity']) && ! empty($consumption['RequestedAmmoLoad']) && ! empty($consumption['CostPerBullet'])) {
            $out['Capacity'] = (int) floor($consumption['RequestedAmmoLoad'] / $consumption['CostPerBullet']);
        }

        return $this->removeNullValues($out);
    }

    /**
     * Dynamic-condition wrappers like Volt weapons hide the real fire actions inside conditionalWeaponActions ... weaponAction and defaultWeaponAction.
     * This flattens them so each inner action becomes its own mode.
     *
     * @return list<Element>
     */
    private function expandFireAction(Element $action): array
    {
        if ($action->nodeName !== 'SWeaponActionDynamicConditionParams') {
            return [$action];
        }

        $actions = [];

        foreach ($action->get('conditionalWeaponActions')?->children() ?? [] as $conditional) {
            foreach ($conditional->get('weaponAction')?->children() ?? [] as $inner) {
                $actions[] = $inner;
            }
        }

        foreach ($action->get('defaultWeaponAction')?->children() ?? [] as $inner) {
            $actions[] = $inner;
        }

        return $actions;
    }

    private function extractLauncherParams(Element $action): ?Element
    {
        return match ($action->nodeName) {
            'SWeaponActionFireChargedParams' => $action->get('weaponAction/SWeaponActionFireSingleParams/launchParams/SProjectileLauncher')
                ?? $action->get('weaponAction/SWeaponActionFireBurstParams/launchParams/SProjectileLauncher'),
            'SWeaponActionSequenceParams' => $action->get('sequenceEntries/SWeaponSequenceEntryParams/weaponAction/SWeaponActionFireSingleParams/launchParams/SProjectileLauncher')
                ?? $action->get('sequenceEntries/SWeaponSequenceEntryParams/weaponAction/SWeaponActionFireBurstParams/launchParams/SProjectileLauncher'),
            default => $action->get('launchParams/SProjectileLauncher'),
        };
    }

    protected function extractSpread(Element $action): array
    {
        $launcher = $this->extractLauncherParams($action);

        if (! $launcher instanceof Element) {
            return [];
        }

        $spread = [
            'Minimum' => $launcher->get('spreadParams@min'),
            'Maximum' => $launcher->get('spreadParams@max'),
            'FirstAttack' => $launcher->get('spreadParams@firstAttack'),
            'Attack' => $launcher->get('spreadParams@attack'),
            'Decay' => $launcher->get('spreadParams@decay'),
        ];

        return $this->removeNullValues($spread);
    }

    private function extractAdsSpread(Element $weapon, array $baseSpread): array
    {
        $modifier = $weapon->get('aimAction/SWeaponActionAimSimpleParams/aimModifier/SWeaponModifierParams/weaponStats/spreadModifier');

        if (! $modifier instanceof Element || $baseSpread === []) {
            return $baseSpread;
        }

        $apply = static function (?float $value, ?float $multiplier, ?float $additive = 0.0): ?float {
            if ($value === null && $additive === null) {
                return null;
            }

            $multiplier ??= 1.0;
            $additive ??= 0.0;

            if ($value === null) {
                return $additive === 0.0 ? null : $additive;
            }

            return ($value * $multiplier) + $additive;
        };

        $ads = [
            'Minimum' => $apply($baseSpread['Min'] ?? null, $modifier->get('minMultiplier'), $modifier->get('additiveModifier')),
            'Maximum' => $apply($baseSpread['Max'] ?? null, $modifier->get('maxMultiplier'), $modifier->get('additiveModifier')),
            'FirstAttack' => $apply($baseSpread['FirstAttack'] ?? null, $modifier->get('firstAttackMultiplier'), $modifier->get('additiveModifier')),
            'Attack' => $apply($baseSpread['Attack'] ?? null, $modifier->get('attackMultiplier'), $modifier->get('additiveModifier')),
            'Decay' => $apply($baseSpread['Decay'] ?? null, $modifier->get('decayMultiplier')),
        ];

        return $this->removeNullValues($ads);
    }

    private function extractSpinTimes(Element $action): array
    {
        if ($action->nodeName !== 'SWeaponActionFireRapidParams') {
            return [];
        }

        $up = $action->get('@spinUpTime');
        $down = $action->get('@spinDownTime');

        $spin = [
            'Up' => $up,
            'Down' => $down,
        ];

        return $this->removeNullValues($spin);
    }

    private function extractChargeContext(Element $action): array
    {
        if ($action->nodeName !== 'SWeaponActionFireChargedParams') {
            return ['Timings' => [], 'Modifier' => []];
        }

        $modifier = $action->get('maxChargeModifier');

        return [
            'Timings' => $this->removeNullValues([
                'ChargeTime' => $action->get('@chargeTime'),
                'OverchargeTime' => $action->get('@overchargeTime'),
                'OverchargedTime' => $action->get('@overchargedTime'),
                'CooldownTime' => $action->get('@cooldownTime'),
                'AutoFire' => $action->get('@fireAutomaticallyOnFullCharge'),
                'RequireFullCharge' => $action->get('@fireOnlyOnFullCharge'),
                'AutoCharge' => $action->get('@chargeAutomatically'),
                'InterpolateBonus' => $action->get('@interpolateChargeBonus'),
            ]),
            'Modifier' => $this->removeNullValues([
                'Damage' => $modifier?->get('@damageMultiplier', 1.0),
                'FireRate' => $modifier?->get('@fireRateMultiplier', 1.0),
                'AmmoSpeed' => $modifier?->get('@projectileSpeedMultiplier'),
                'AmmoCost' => $modifier?->get('@ammoCost'),
                'AmmoCostMultiplier' => $modifier?->get('@ammoCostMultiplier'),
                'FireRateOverride' => $modifier?->get('@fireRate'),
                'PelletsOverride' => $modifier?->get('@pellets'),
                'BurstShotsOverride' => $modifier?->get('@burstShots'),
                'HeatMultiplier' => $modifier?->get('@heatGenerationMultiplier'),
            ]),
        ];
    }

    private function extractDamageMultiplier(?Element $launcher, array $chargeModifier): float
    {
        $base = $launcher?->get('@damageMultiplier') ?? 1.0;
        $charge = $chargeModifier['Damage'] ?? 1.0;

        return (float) $base * (float) $charge;
    }

    protected function calculateBeamDamage(Element $action): array
    {
        $damageInfo = $action->get('damagePerSecond/DamageInfo');
        $byType = [];
        $total = 0.0;

        foreach (self::$resistanceKeys as $key) {
            $value = (float) ($damageInfo?->get('@Damage'.$key) ?? 0);
            $byType[$key] = $value;
            $total += $value;
        }

        return ['Total' => $total, 'ByType' => $byType];
    }

    protected function calculateDamage(?array $ammunition, float $pellets, float $damageMultiplier): array
    {
        $ammo = is_array($ammunition) ? $ammunition : [];
        $impact = $ammo['ImpactDamage'] ?? [];
        $detonation = $ammo['DetonationDamage'] ?? [];

        $byType = [];
        $total = 0.0;

        foreach (self::$resistanceKeys as $key) {
            $value = (($impact[$key] ?? 0) + ($detonation[$key] ?? 0)) * $pellets * $damageMultiplier;
            $byType[$key] = $value;
            $total += $value;
        }

        return ['Total' => $total, 'ByType' => $byType];
    }

    protected function calculateDamagePerSecond(float $damagePerShot, ?float $rpm): float
    {
        if ($rpm === null) {
            return 0.0;
        }

        return $damagePerShot * ($rpm / 60.0);
    }

    private function buildDamagePerSecondByType(array $damageByType, ?float $rpm): array
    {
        $result = [];

        if ($rpm === null) {
            foreach (self::$resistanceKeys as $key) {
                $result[$key] = 0.0;
            }

            return $result;
        }

        foreach (self::$resistanceKeys as $key) {
            $result[$key] = ($damageByType[$key] ?? 0) * ($rpm / 60.0);
        }

        return $result;
    }

    private function calculateEffectiveRpm(?float $rpm, Element $action, array $chargeModifier): ?float
    {
        if ($rpm === null) {
            return null;
        }

        if ($action->nodeName === 'SWeaponActionFireChargedParams') {
            $chargeTime = (float) ($action->get('@chargeTime') ?? 0);
            $cooldown = (float) ($action->get('@cooldownTime') ?? 0);

            $timedCycle = $chargeTime + $cooldown;
            if ($timedCycle > 0) {
                $rpmFromTiming = 60.0 / $timedCycle;

                return $rpmFromTiming * (float) ($chargeModifier['FireRate'] ?? 1.0);
            }
        }

        $rpm *= (float) ($chargeModifier['FireRate'] ?? 1.0);

        if ($rpm === 0.0) {
            return null;
        }

        $cycleTime = 60.0 / $rpm;

        return $cycleTime > 0 ? 60.0 / $cycleTime : null;
    }

    protected function roundStat(?float $value, int $precision = 1): ?float
    {
        if ($value === null) {
            return null;
        }

        return round($value, $precision);
    }

    private function resolveEffectiveRange(Element $weapon, ?array $ammunition): ?float
    {
        $range = $weapon->get('effectiveRange');

        if ($range !== null) {
            return (float) $range;
        }

        // For beam-type weapons, use the fire action's range instead of ammunition range
        $beamRange = $this->resolveBeamRange($weapon);

        return $beamRange ?? $ammunition['Range'] ?? null;
    }

    /**
     * Resolve effective range from the first beam-type fire action.
     *
     * Beam-type weapons (beam, healing, salvage, gathering, tractor) define their
     * range on the fire action element, not in the ammunition's Speed * Lifetime.
     *
     * @return float|null Range in meters, or null if no beam action found
     */
    private function resolveBeamRange(Element $weapon): ?float
    {
        $firstAction = $weapon->get('fireActions')?->children()->current();

        if (! $firstAction instanceof Element) {
            return null;
        }

        return match ($firstAction->nodeName) {
            'SWeaponActionFireBeamParams' => (float) ($firstAction->get('@fullDamageRange') ?? 0) ?: null,
            'SWeaponActionFireHealingBeamParams' => (float) ($firstAction->get('@maxDistance') ?? 0) ?: null,
            'SWeaponActionFireSalvageRepairParams' => (float) ($firstAction->get('rangeParams@maxBeamDistance') ?? 0) ?: null,
            'SWeaponActionGatheringBeamParams' => (float) ($firstAction->get('@maximumDistance') ?? 0) ?: null,
            'SWeaponActionFireTractorBeamParams' => (float) ($firstAction->get('@maxDistance') ?? 0) ?: null,
            default => null,
        };
    }

    private function buildMagazine(): array
    {
        $magazineEntity = $this->item->getMagazine();
        $magazine = $magazineEntity?->get('Components/SAmmoContainerComponentParams');

        if ($magazine === null) {
            return [];
        }

        return [
            'UUID' => $magazine->get('@ammoParamsRecord'),
            'Type' => $magazineEntity?->getAttachSubType(),
            'InitialAmmoCount' => $magazine->get('@initialAmmoCount'),
            'MaxAmmoCount' => $magazine->get('@maxAmmoCount'),
            'MaxRestockCount' => $magazine->get('@maxRestockCount'),
        ];
    }

    private function buildAttachments(): array
    {
        $entries = $this->item->get('Components/SEntityComponentDefaultLoadoutParams/loadout/SItemPortLoadoutManualParams/entries');

        if ($entries === null) {
            return [];
        }

        $attachments = [];
        $itemService = ServiceFactory::getItemService();

        foreach ($entries->children() as $entry) {
            $portName = $entry->get('@itemPortName');
            $className = $entry->get('@entityClassName');

            if (empty($portName)) {
                continue;
            }

            $uuid = null;
            if (! empty($className)) {
                try {
                    $item = $itemService->getByClassName($className);
                    $uuid = $item?->getUuid();
                } catch (Exception $e) {
                    // Item not found or error loading - leave UUID as null
                }
            }

            $attachments[] = array_filter([
                'UUID' => $uuid,
                'Port' => $portName,
                'ClassName' => $className ?: null,
            ]);
        }

        return $attachments;
    }
}
