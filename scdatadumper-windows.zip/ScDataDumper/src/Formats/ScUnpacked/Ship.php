<?php

namespace Octfx\ScDataDumper\Formats\ScUnpacked;

use Illuminate\Support\Arr;
use Octfx\ScDataDumper\DocumentTypes\Vehicle;
use Octfx\ScDataDumper\Formats\BaseFormat;
use Octfx\ScDataDumper\Helper\Element;
use Octfx\ScDataDumper\Helper\ItemDescriptionParser;
use Octfx\ScDataDumper\Helper\VehicleWrapper;
use Octfx\ScDataDumper\Services\DataDumper\SocpakReader;
use Octfx\ScDataDumper\Services\ItemClassifierService;
use Octfx\ScDataDumper\Services\PortClassifierService;
use Octfx\ScDataDumper\Services\ServiceFactory;
use Octfx\ScDataDumper\Services\Vehicle\CargoGridResolver;
use Octfx\ScDataDumper\Services\Vehicle\DriveCharacteristics\DriveCharacteristicsCalculator;
use Octfx\ScDataDumper\Services\Vehicle\DriveCharacteristics\DriveCharacteristicsVehicleCalculator;
use Octfx\ScDataDumper\Services\Vehicle\EmissionAggregator;
use Octfx\ScDataDumper\Services\Vehicle\FlightCharacteristicsCalculator;
use Octfx\ScDataDumper\Services\Vehicle\HealthAggregator;
use Octfx\ScDataDumper\Services\Vehicle\InventoryContainerResolver;
use Octfx\ScDataDumper\Services\Vehicle\LoadoutPortIdentityAnnotator;
use Octfx\ScDataDumper\Services\Vehicle\PortFinder;
use Octfx\ScDataDumper\Services\Vehicle\PortSummaryBuilder;
use Octfx\ScDataDumper\Services\Vehicle\PropulsionSystemAggregator;
use Octfx\ScDataDumper\Services\Vehicle\QuantumTravelCalculator;
use Octfx\ScDataDumper\Services\Vehicle\ResourceAggregator;
use Octfx\ScDataDumper\Services\Vehicle\SeatingAnalyzer;
use Octfx\ScDataDumper\Services\Vehicle\SocpakObjectCollector;
use Octfx\ScDataDumper\Services\Vehicle\StanceSpeedExtractor;
use Octfx\ScDataDumper\Services\Vehicle\StandardisedPartBuilder;
use Octfx\ScDataDumper\Services\Vehicle\StandardisedPartWalker;
use Octfx\ScDataDumper\Services\Vehicle\SystemsBuilder;
use Octfx\ScDataDumper\Services\Vehicle\TurretControlMapper;
use Octfx\ScDataDumper\Services\Vehicle\TurretDpsEnricher;
use Octfx\ScDataDumper\Services\Vehicle\VehicleDataContext;
use Octfx\ScDataDumper\Services\Vehicle\VehicleDataOrchestrator;
use Octfx\ScDataDumper\Services\Vehicle\WeaponDpsAggregator;
use Octfx\ScDataDumper\Services\Vehicle\WeaponSystemAnalyzer;

final class Ship extends BaseFormat
{
    protected ?string $elementKey = 'Components/SAttachableComponentParams/AttachDef';

    private readonly CargoGridResolver $cargoGridResolver;

    private readonly InventoryContainerResolver $inventoryContainerResolver;

    private readonly PortSummaryBuilder $portSummaryBuilder;

    private readonly StandardisedPartBuilder $standardisedPartBuilder;

    private readonly ?Vehicle $vehicle;

    private readonly ?Element $entityPorts;

    public function __construct(private readonly VehicleWrapper $vehicleWrapper)
    {
        parent::__construct($this->vehicleWrapper->entity);

        $this->vehicle = $this->vehicleWrapper->vehicle;

        $this->cargoGridResolver = new CargoGridResolver;
        $this->inventoryContainerResolver = new InventoryContainerResolver;
        $this->portSummaryBuilder = new PortSummaryBuilder(new PortFinder);
        $this->entityPorts = $this->vehicleWrapper->entity->get('Components/SItemPortContainerComponentParams/Ports');

        $this->standardisedPartBuilder = new StandardisedPartBuilder(
            ServiceFactory::getItemService(),
            new ItemClassifierService,
            new PortClassifierService,
            $this->entityPorts,
        );
    }

    public function toArray(): array
    {
        $attach = $this->vehicleWrapper->entity->getAttachDef();

        $manufacturer = $this->vehicleWrapper->entity->getManufacturer();

        $wikiCode = $manufacturer !== null
            ? ServiceFactory::getDataOverrideService()->factsFor($this->vehicleWrapper->entity->getUuid())['manufacturer'] ?? null
            : null;
        $resolvedManufacturer = ServiceFactory::getManufacturerService()
            ->resolveForEntity($manufacturer, $wikiCode);

        $isVehicle = $this->vehicleWrapper->entity->isGroundVehicle();
        $isGravlev = $this->vehicleWrapper->entity->isGravlev();
        $isPowerSuit = $this->vehicleWrapper->entity->isActorVehicle();
        $dimensions = $this->vehicleWrapper->entity->getDimensions();

        $vehicleNameKey = $this->vehicleWrapper->entity->getVehicleNameKey();
        $vehicleName = $vehicleNameKey !== null && $vehicleNameKey !== ''
            ? $this->translateLocalizationValue($vehicleNameKey)
            : $attach?->get('Localization@Name');
        $vehicleDescriptionKey = $this->vehicleWrapper->entity->getVehicleDescriptionKey();
        $vehicleDescription = $vehicleDescriptionKey !== null && $vehicleDescriptionKey !== ''
            ? $this->translateLocalizationValue($vehicleDescriptionKey)
            : $attach?->get('Localization@Description');
        $vehicleCareerKey = $this->vehicleWrapper->entity->getCareerKey();
        $vehicleCareerLabel = $vehicleCareerKey !== null && $vehicleCareerKey !== ''
            ? $this->translateLocalizationValue($vehicleCareerKey)
            : null;
        $vehicleRoleKey = $this->vehicleWrapper->entity->getRoleKey();
        $vehicleRoleLabel = $vehicleRoleKey !== null && $vehicleRoleKey !== ''
            ? $this->translateLocalizationValue($vehicleRoleKey)
            : null;

        if ($vehicleCareerLabel === '' || $vehicleCareerLabel === null) {
            $vehicleCareerLabel = $this->item->get('StaticEntityClassData/SEntityInsuranceProperties/displayParams@career') ?? '';
        }

        if ($vehicleRoleLabel === '' || $vehicleRoleLabel === null) {
            $vehicleRoleLabel = $this->item->get('StaticEntityClassData/SEntityInsuranceProperties/displayParams@role') ?? '';
        }

        $descriptionData = ItemDescriptionParser::parse($vehicleDescription);

        $physicsParams = $this->vehicleWrapper->entity->getPhysicsParams();

        $data = [
            'UUID' => $this->item->getUuid(),
            'ClassName' => $this->item->getClassName(),
            'Name' => trim($vehicleName !== '' ? $vehicleName : $this->item->getClassName()),
            'NameKey' => $vehicleNameKey !== null && $vehicleNameKey !== '' ? ltrim($vehicleNameKey, '@') : null,
            'Description' => $vehicleDescription,
            'DescriptionKey' => $vehicleDescriptionKey !== null && $vehicleDescriptionKey !== '' ? ltrim($vehicleDescriptionKey, '@') : null,
            'DescriptionData' => $descriptionData['data'] ?? null,
            'DescriptionText' => $descriptionData['description'] ?? null,

            'Career' => $vehicleCareerLabel,
            'CareerKey' => $vehicleCareerKey !== null && $vehicleCareerKey !== '' ? ltrim($vehicleCareerKey, '@') : null,
            'Role' => $vehicleRoleLabel,
            'RoleKey' => $vehicleRoleKey !== null && $vehicleRoleKey !== '' ? ltrim($vehicleRoleKey, '@') : null,

            'Manufacturer' => $resolvedManufacturer !== null ? [
                'UUID' => $resolvedManufacturer['uuid'],
                'Code' => $resolvedManufacturer['code'],
                'Name' => $resolvedManufacturer['name'],
            ] : [],

            'Size' => $attach?->get('@Size', 0) ?? 0,
            'Length' => $dimensions[0] ?? 0,
            'Width' => $dimensions[1] ?? 0,
            'Height' => $dimensions[2] ?? 0,
            'Crew' => $this->vehicleWrapper->entity->getCrewSize(),

            'Insurance' => $this->vehicleWrapper->entity->getInsuranceParams(),

            'IsVehicle' => $isVehicle,
            'IsGravlev' => $isGravlev,
            'IsSpaceship' => $this->vehicleWrapper->entity->isSpaceship(),
            'IsPowerSuit' => $isPowerSuit,

            'PenetrationMultiplier' => [
                'Fuse' => $this->vehicleWrapper->entity->getFusePenetrationMultiplier(),
                'Components' => $this->vehicleWrapper->entity->getComponentPenetrationMultiplier(),
            ],

            'PortTags' => $this->vehicle?->getPortTags() ?? [],
        ];

        // Actors / ATLS
        if ($physicsParams) {
            $physicsData = $physicsParams->attributesToArray();

            $data['IsSpaceship'] = false;
            $data['IsVehicle'] = true;
            $data['Physics'] = [
                'Mass' => (float) ($physicsData['Mass'] ?? 0),
                'Inertia' => (float) ($physicsData['inertia'] ?? 0),
                'InertiaAccel' => (float) ($physicsData['inertiaAccel'] ?? 0),
                'AirResistance' => (float) ($physicsData['airResistance'] ?? 0),
                'AirControl' => (float) ($physicsData['airControl'] ?? 0),
                'MaxVelGround' => (float) ($physicsData['maxVelGround'] ?? 0),
                'MinSlideAngle' => (float) ($physicsData['minSlideAngle'] ?? 0),
                'MaxClimbAngle' => (float) ($physicsData['maxClimbAngle'] ?? 0),
                'MinFallAngle' => (float) ($physicsData['minFallAngle'] ?? 0),
                'MinColSpeedForExternalForceEvent' => (float) ($physicsData['minColSpeedForExternalForceEvent'] ?? 0),
                'MinSpeedForChargeCollisionDamage' => (float) ($physicsData['minSpeedForChargeCollisionDamage'] ?? 0),
                'ChargeAttackDamage' => (float) ($physicsData['chargeAttackDamage'] ?? 0),
            ];

            $stanceSpeed = (new StanceSpeedExtractor)->extract($this->vehicleWrapper->entity);
            if ($stanceSpeed !== null) {
                $data['StanceSpeed'] = $stanceSpeed;
            }
        }

        // Build standardised parts with loadout
        $standardisedParts = $this->standardisedPartBuilder->buildPartList(
            $this->vehicle?->get('Parts')?->children() ?? [],
            $this->vehicleWrapper->loadout
        );

        if (! empty($standardisedParts)) {
            $data['Parts'] = $this->buildPartsTree($standardisedParts);
        }

        $walker = new StandardisedPartWalker;

        $data['Mass'] = 0.0;

        foreach ($walker->walkParts($standardisedParts) as $part) {
            $data['Mass'] += Arr::get($part, 'part.Mass', 0.0);
        }

        if ($data['Mass'] === 0.0 && $physicsParams) {
            $physicsData = $physicsParams->attributesToArray();
            $data['Mass'] = (float) ($physicsData['Mass'] ?? 0);
        }

        $portSummary = $this->portSummaryBuilder->build($standardisedParts);

        // Build turret control map: which turrets are bridge-controllable
        $turretControlMap = (new TurretControlMapper)->getBridgeControllableTurrets(
            $this->vehicle,
            $this->vehicleWrapper->entity,
        );

        $socpakReader = new SocpakReader(ServiceFactory::getActiveScDataPath());
        $socpakObjects = new SocpakObjectCollector($socpakReader)->collectAll(
            $this->vehicleWrapper->entity,
            $this->vehicleWrapper->loadout,
        );

        $context = new VehicleDataContext(
            standardisedParts: $standardisedParts,
            portSummary: $portSummary,
            ifcsLoadoutEntry: Arr::get($portSummary, 'flightControllers.0.Port.InstalledItem.stdItem'),
            mass: $data['Mass'],
            loadoutMass: 0.0,
            isVehicle: $isVehicle,
            isGravlev: $isGravlev,
            isSpaceship: ! ($isVehicle || $isGravlev),
            turretControlMap: $turretControlMap,
            intermediateResults: [],
            entity: $this->vehicleWrapper->entity,
            loadout: $this->vehicleWrapper->loadout,
            socpakObjects: $socpakObjects,
        );

        $calculators = [
            new EmissionAggregator($walker, $this->vehicleWrapper),
            new ResourceAggregator(
                walker: $walker,
                itemService: ServiceFactory::getItemService(),
            ),
            new PropulsionSystemAggregator,
            new QuantumTravelCalculator,
            new FlightCharacteristicsCalculator,
            new HealthAggregator($walker),
            new WeaponDpsAggregator($walker),
            new WeaponSystemAnalyzer,
            new SeatingAnalyzer(itemService: ServiceFactory::getItemService()),
            new DriveCharacteristicsVehicleCalculator(
                new DriveCharacteristicsCalculator,
                $this->vehicleWrapper
            ),
        ];

        $orchestrator = new VehicleDataOrchestrator($calculators);
        $calculatedData = $orchestrator->calculate($context);

        $data['MassLoadout'] = $calculatedData['mass_loadout'] ?? null;
        $data['MassTotal'] = round($data['Mass'] + ($data['MassLoadout'] ?? 0));
        $data['Mass'] = round($data['Mass']);

        // Crew roles derived from installed turrets
        $weaponCrew = ($portSummary['mannedTurrets']->count() ?? 0) + ($portSummary['remoteTurrets']->count() ?? 0);
        $operationsCrew = max(
            $portSummary['miningTurrets']->count() ?? 0,
            $portSummary['utilityTurrets']->count() ?? 0
        );

        $data['WeaponCrew'] = $weaponCrew ?: null;
        $data['OperationsCrew'] = $operationsCrew ?: null;

        if (! empty($calculatedData['Seating'])) {
            $data['Seating'] = $calculatedData['Seating'];
            $data['Seats'] = Arr::get($calculatedData['Seating'], 'CrewStations');
        }

        $summary = [];

        // Shield Face Type + Shield Resistance/Absorption
        $shields = [];
        foreach ($walker->walkItems($standardisedParts) as $entry) {
            if (Arr::has($entry, 'Item.stdItem.ShieldController')) {
                $data['ShieldController'] = Arr::get($entry, 'Item.stdItem.ShieldController');
            }

            // Collect shield generators for resistance/absorption rollup
            $item = $entry['Item'] ?? null;
            $itemType = $item['type'] ?? null;

            if ($itemType === 'Shield') {
                $stdItem = Arr::get($item, 'stdItem');

                if ($stdItem !== null) {
                    $shields[] = $stdItem;
                }
            }
        }

        // Shield Resistance/Absorption: average across active shields only
        $shieldResistance = null;
        $shieldAbsorption = null;

        if ($shields !== []) {
            $maxShields = $this->vehicleWrapper->entity->getShieldPoolMaxCount();
            $activeShields = array_slice($shields, 0, $maxShields);

            $resistance = $this->averageShieldMinMax($activeShields, 'Shield.Resistance');

            if ($resistance !== null) {
                $shieldResistance = $resistance;
            }

            $absorption = $this->averageShieldMinMax($activeShields, 'Shield.Absorption');

            if ($absorption !== null) {
                $shieldAbsorption = $absorption;
            }
        }

        if ($portSummary['armor']->count() > 0) {
            $armor = Arr::get($portSummary['armor']->first(), 'Port.InstalledItem.stdItem', []);

            $data['armor'] = [
                'UUID' => Arr::get($armor, 'UUID'),
                'Health' => Arr::get($armor, 'Durability.Health'),
                'ResistanceMultipliers' => array_map(static fn ($mult) => $mult['Multiplier'], Arr::get($armor, 'Durability.Resistance', [])),
                ...Arr::get($armor, 'Armor', []),
            ];
        }

        $crossSectionParams = $this->vehicleWrapper->entity->getCrossSectionParams();

        if ($crossSectionParams !== null) {
            $data['cross_section'] = array_map(static fn ($x): float => (float) $x, $crossSectionParams);
        }

        $cargoResult = $this->cargoGridResolver->resolveCargoGrids($this->vehicleWrapper);

        $summary['Cargo'] = $cargoResult->totalCapacity;

        if ($cargoResult->oreCapacity > 0) {
            $summary['OreCapacity'] = round($cargoResult->oreCapacity, 2);
        }

        $summary['CargoGrids'] = $cargoResult->grids->map(function ($grid) {
            return $this->transformArrayKeysToPascalCase($grid);
        });
        $cargoSizeLimits = $this->cargoGridResolver->calculateCargoGridSizeLimits($cargoResult->grids);
        $summary['CargoSizeLimits'] = $this->transformArrayKeysToPascalCase($cargoSizeLimits);

        $inventoryResult = $this->inventoryContainerResolver->resolveInventoryContainers(
            $this->vehicleWrapper,
            socpakObjects: $socpakObjects,
        );

        if ($inventoryResult->stowageCapacity > 0) {
            $summary['Stowage'] = round($inventoryResult->stowageCapacity, 2);
        }

        if ($inventoryResult->containers->isNotEmpty()) {
            $summary['InventoryContainers'] = $inventoryResult->containers->map(function ($container) {
                return $this->transformArrayKeysToPascalCase($container);
            });
        }

        $data['emission'] = $data['emission'] ?? $calculatedData['emission'] ?? [];
        $data['cooling'] = $calculatedData['cooling'] ?? [];
        $data['power'] = $calculatedData['power'] ?? [];
        $data['power_pools'] = $calculatedData['power_pools'] ?? [];
        $data['shields_total'] = $calculatedData['shields_total'] ?? [];

        if (isset($shieldResistance)) {
            $data['shields_total']['Resistance'] = $shieldResistance;
        }

        if (isset($shieldAbsorption)) {
            $data['shields_total']['Absorption'] = $shieldAbsorption;
        }

        // Keep Systems.Shields.Summary in parity with the enriched top-level ShieldsTotal payload.
        $calculatedData['shields_total'] = $data['shields_total'];

        // deprecated, use shields_total.hp
        $data['shield_hp'] = round($calculatedData['shields_total']['hp'] ?? 0);
        $data['distortion'] = $calculatedData['distortion'] ?? [];
        $data['ammo'] = $calculatedData['ammo'] ?? [];
        $data['weapon_storage'] = $calculatedData['weapon_storage'] ?? [];
        $data['suit_storage'] = $calculatedData['suit_storage'] ?? [];

        // Add calculator data to summary
        if (! empty($calculatedData['Health'])) {
            $summary['Health'] = round($calculatedData['Health']);
        }

        if (! empty($calculatedData['DamageBeforeDestruction'])) {
            $summary['DamageBeforeDestruction'] = $calculatedData['DamageBeforeDestruction'];
        }

        if (! empty($calculatedData['DamageBeforeDetach'])) {
            $summary['DamageBeforeDetach'] = $calculatedData['DamageBeforeDetach'];
        }

        if (! empty($calculatedData['FlightCharacteristics'])) {
            $summary['FlightCharacteristics'] = $calculatedData['FlightCharacteristics'];
        }

        if (! empty($calculatedData['Agility'])) {
            $data['Agility'] = $calculatedData['Agility'];
        }

        if (! empty($calculatedData['MannedTurrets'])) {
            $summary['MannedTurrets'] = $calculatedData['MannedTurrets'];
        }

        if (! empty($calculatedData['PdcTurrets'])) {
            $summary['PdcTurrets'] = $calculatedData['PdcTurrets'];
        }

        if (! empty($calculatedData['RemoteTurrets'])) {
            $summary['RemoteTurrets'] = $calculatedData['RemoteTurrets'];
        }

        // Merge Weaponry.Turrets DPS data into typed turret arrays
        $weaponryTurrets = $calculatedData['Weaponry']['Turrets'] ?? [];
        if (! empty($weaponryTurrets)) {
            $turretDpsMap = [];
            foreach ($weaponryTurrets as $turret) {
                $turretDpsMap[$turret['HardpointName']] = $turret;
            }

            foreach (['MannedTurrets', 'PdcTurrets', 'RemoteTurrets'] as $key) {
                if (empty($calculatedData[$key])) {
                    continue;
                }
                foreach ($calculatedData[$key] as $i => $turret) {
                    $hp = $turret['HardpointName'] ?? null;
                    if ($hp !== null && isset($turretDpsMap[$hp])) {
                        $dps = $turretDpsMap[$hp];
                        $calculatedData[$key][$i]['DpsTotal'] = $dps['DpsTotal'] ?? null;
                        $calculatedData[$key][$i]['SustainedDpsTotal'] = $dps['SustainedDpsTotal'] ?? null;
                        $calculatedData[$key][$i]['AlphaTotal'] = $dps['AlphaTotal'] ?? null;
                        $calculatedData[$key][$i]['Weapons'] = $dps['Weapons'] ?? [];
                        $calculatedData[$key][$i]['IsPilotSlaveable'] = $dps['IsPilotSlaveable'] ?? false;
                    }
                }
            }

            // Re-assign merged turret arrays to summary
            if (! empty($calculatedData['MannedTurrets'])) {
                $summary['MannedTurrets'] = $calculatedData['MannedTurrets'];
            }
            if (! empty($calculatedData['PdcTurrets'])) {
                $summary['PdcTurrets'] = $calculatedData['PdcTurrets'];
            }
            if (! empty($calculatedData['RemoteTurrets'])) {
                $summary['RemoteTurrets'] = $calculatedData['RemoteTurrets'];
            }
        }
        if (! empty($calculatedData['Propulsion'])) {
            $summary['Propulsion'] = $calculatedData['Propulsion'];
        }
        if (! empty($calculatedData['Weaponry'])) {
            $weaponry = $calculatedData['Weaponry'];
            unset($weaponry['Turrets']);
            if (! empty($weaponry)) {
                $summary['Weaponry'] = $weaponry;
            }
        }
        if (! empty($calculatedData['QuantumTravel'])) {
            $summary['QuantumTravel'] = $calculatedData['QuantumTravel'];
        }
        if (! empty($calculatedData['DriveCharacteristics'])) {
            $summary['DriveCharacteristics'] = $calculatedData['DriveCharacteristics'];
        }

        $loadout = $this->buildLoadout($standardisedParts);

        if (! empty($loadout)) {
            if (! empty($turretControlMap)) {
                $this->markPilotSlaveable($loadout, $turretControlMap);
            }

            $loadout = (new LoadoutPortIdentityAnnotator)->annotate($loadout);
            $loadout = (new TurretDpsEnricher)->enrich($loadout, $calculatedData);
            $data['loadout'] = $loadout;
        }

        // Engineering boost (multi-crew weapon regen modifier)
        $engineeringBoostItem = $this->vehicleWrapper->entity->getEngineeringBoostItem();
        if ($engineeringBoostItem !== null) {
            $engineeringBoost = new EngineeringBoost($engineeringBoostItem)->toArray();
            if ($engineeringBoost !== null) {
                $data['engineering_boost'] = $engineeringBoost;
            }
        }

        // Relay network topology
        $relayNetwork = new RelayNetwork($this->vehicleWrapper->entity, $this->vehicleWrapper->loadout, $loadout);
        if ($relayNetwork->canTransform()) {
            $data['RelayNetwork'] = $relayNetwork->toArray();
        }

        // Ship-to-ship service provider (CryAstro-style repair/restock/refuel for hangar ships)
        $shipServices = new ShipServices($this->vehicleWrapper->entity);
        if ($shipServices->canTransform()) {
            $data['ShipServices'] = $shipServices->toArray();
        }

        $data = array_merge($data, $summary);

        // Build semantic Systems index from annotated loadout
        $systems = (new SystemsBuilder)->build(
            annotatedLoadout: $loadout ?? [],
            calculatedData: $calculatedData,
            legacyPortSummary: $portSummary,
        );
        $data['systems'] = $systems;

        $this->processArray($data);

        $data = $this->transformArrayKeysToPascalCase($data);

        return $this->removeNullValuesPreservingEmptyArrays($data);
    }

    private function processArray(&$array): void
    {
        foreach ($array as &$value) {
            if (is_array($value)) {
                $this->processArray($value);
            } elseif ($value instanceof BaseFormat) {
                $value = $value->toArray();

                if (is_array($value)) {
                    $this->processArray($value);
                }
            }
        }
    }

    /**
     * Convert flat Types array to grouped CompatibleTypes format.
     * Example: ['WeaponGun.Ballistic', 'WeaponGun.Energy', 'WeaponMining']
     *   -> [{Type: 'WeaponGun', SubTypes: ['Ballistic', 'Energy']}, {Type: 'WeaponMining'}]
     *
     * @param  list<string>  $types  Dot-separated type strings from extractTypes()
     * @return list<array{Type: string, SubTypes?: list<string>}>
     */
    private function buildCompatibleTypes(array $types): array
    {
        $grouped = [];

        foreach ($types as $typeString) {
            $parts = explode('.', $typeString, 2);
            $major = $parts[0];
            $minor = $parts[1] ?? null;

            if (! isset($grouped[$major])) {
                $grouped[$major] = [];
            }

            if ($minor !== null && ! in_array($minor, $grouped[$major], true)) {
                $grouped[$major][] = $minor;
            }
        }

        $result = [];

        foreach ($grouped as $type => $subTypes) {
            $entry = ['Type' => $type];

            if ($subTypes !== []) {
                $entry['SubTypes'] = $subTypes;
            }

            $result[] = $entry;
        }

        return $result;
    }

    /**
     * Determine if children are editable.
     * If no children exist, match parent's editable status.
     * If children exist, check if any are editable.
     */
    private function determineEditableChildren(?array $nestedLoadout, bool $parentEditable): bool
    {
        if ($nestedLoadout === null || empty($nestedLoadout)) {
            return $parentEditable;
        }

        return array_any($nestedLoadout, fn ($childEntry) => ($childEntry['editable'] ?? false) === true);
    }

    /**
     * Recursively build nested loadout from ports.
     */
    private function buildNestedLoadout(array $ports): array
    {
        $result = [];

        foreach ($ports as $childPort) {
            $entry = $this->buildLoadoutEntry($childPort);
            if ($entry !== null) {
                $result[] = $entry;
            }
        }

        return $result;
    }

    /**
     * Build a single loadout entry from port data.
     */
    private function buildLoadoutEntry(array $port): ?array
    {
        $portName = $port['PortName'] ?? null;

        $installedItemPayload = $port['InstalledItem'] ?? null;
        $installedItem = is_array($installedItemPayload) ? ($installedItemPayload['stdItem'] ?? null) : null;
        $semanticType = is_array($installedItem) ? ($installedItem['Type'] ?? null) : null;
        $uneditable = $port['Uneditable'] ?? false;

        $entry = [
            'HardpointName' => $portName,
        ];

        if ($installedItem) {
            $entry['ClassName'] = $installedItem['ClassName'] ?? null;
            $entry['UUID'] = $installedItem['UUID'] ?? null;
            $entry['Name'] = $installedItem['Name'] ?? null;
            $entry['ManufacturerName'] = $installedItem['Manufacturer']['Name'] ?? null;
            $entry['Type'] = $semanticType;
            $entry['Grade'] = $installedItem['Grade'] ?? null;
        }

        $nestedLoadout = null;
        if ($installedItem && isset($installedItem['Ports']) && is_array($installedItem['Ports'])) {
            $nestedLoadout = $this->buildNestedLoadout($installedItem['Ports']);
        }

        if ($nestedLoadout !== null && ! empty($nestedLoadout)) {
            $entry['Loadout'] = $nestedLoadout;
        }

        $entry['Editable'] = ! $uneditable;
        $entry['EditableChildren'] = $this->determineEditableChildren($nestedLoadout, ! $uneditable);
        $entry['CompatibleTypes'] = $this->buildCompatibleTypes($port['Types'] ?? []);
        $entry['MaxSize'] = (int) ($port['MaxSize'] ?? 0);
        $entry['MinSize'] = (int) ($port['MinSize'] ?? 0);
        $requiredTags = $port['RequiredTags'] ?? [];

        if (empty($requiredTags) && is_array($installedItem)) {
            // Fall back to the equipped item's RequiredTags when the port
            // definition has no RequiredPortTags (e.g. virtual ports for
            // paint or flight controller on ships like the Avenger Stalker).
            $requiredTags = $installedItem['RequiredTags'] ?? [];
        }

        if (! empty($requiredTags)) {
            $entry['RequiredTags'] = is_array($requiredTags)
                ? array_values(array_filter($requiredTags))
                : array_values(array_filter(explode(' ', trim((string) $requiredTags))));

            if ($entry['RequiredTags'] === []) {
                unset($entry['RequiredTags']);
            }
        }

        // Export PortTags: ship-level tags merged with per-port PortTags from SItemPortDef
        $portTags = $port['PortTags'] ?? [];

        if (! empty($portTags)) {
            $entry['PortTags'] = array_values(array_unique($portTags));
        }

        return $entry;
    }

    private function buildPartsTree(array $parts): array
    {
        $result = [];

        foreach ($parts as $part) {
            $displayName = $part['DisplayName']
                ?? Arr::get($part, 'Port.DisplayName')
                ?? $part['Name']
                ?? null;

            $damageMax = $part['MaximumDamage'] ?? 0.0;
            if (($damageMax === null || (int) $damageMax === 0) && empty($part['Parts'])) {
                continue;
            }

            $result[] = [
                'name' => $part['Name'] ?? null,
                'display_name' => $displayName,
                'damage_max' => $damageMax,
                'children' => $this->buildPartsTree($part['Parts'] ?? []),
            ];
        }

        return $result;
    }

    /**
     * Build loadout array from standardised parts.
     * Flattens all categories into a single loadout array.
     */
    private function buildLoadout(array $standardisedParts): array
    {
        $loadout = [];
        $walker = new StandardisedPartWalker;

        foreach ($walker->walkParts($standardisedParts) as $entry) {
            $part = $entry['part'];
            $port = $part['Port'] ?? null;

            if ($port === null) {
                continue;
            }

            $loadoutEntry = $this->buildLoadoutEntry($port);
            if ($loadoutEntry !== null) {
                $loadout[] = $loadoutEntry;
            }
        }

        // Port definitions can lag a hull generation behind (the Constellation Mk V port kept the Mk IV tag), and virtual paint ports carry no tag at all.
        $paintIndex = array_find_key($loadout, static fn (array $e): bool => ($e['HardpointName'] ?? '') === 'hardpoint_paint');

        if ($paintIndex !== null) {
            $current = $loadout[$paintIndex]['RequiredTags'] ?? null;

            if ($current === null || count($current) === 1) {
                $hullTag = $this->extractPaintTagFromGeometry($current === null);

                if ($hullTag !== null && ($current === null || str_starts_with($hullTag, $current[0].'_'))) {
                    $loadout[$paintIndex]['RequiredTags'] = [$hullTag];
                }
            }
        }

        return $loadout;
    }

    /**
     * Extract the base paint compatibility tag from SGeometryResourceParams SubGeometry.
     *
     * All SubGeometry paint tags follow the pattern "Paint_{Base}_{Variant}".
     * The base tag (e.g. "Paint_Avenger" or "Paint_890J") is the common prefix
     * shared by all paint variants, stripped of the trailing underscore.
     *
     * The geometry tag uses the internal platform codename which may differ from
     * the actual paint item's RequiredTags (e.g. "Paint_Atlas" vs "Paint_Centurion").
     * To handle this, we look up an actual paint item by class name and prefer its
     * RequiredTags value when available.
     */
    private function extractPaintTagFromGeometry(bool $allowLiveryLookup): ?string
    {
        $paintTags = [];

        foreach ($this->vehicleWrapper->entity->getAll('Components/SGeometryResourceParams/Geometry/SubGeometry/SGeometryNodeParams@Tags', raw: true) as $tags) {
            $tags = trim((string) $tags);

            if (str_starts_with($tags, 'Paint_')) {
                $paintTags[] = $tags;
            }
        }

        if ($paintTags === []) {
            return null;
        }

        // Derive the geometry-based base tag for class name lookup.
        $baseTag = $this->extractBasePaintTag($paintTags);

        if ($baseTag === null) {
            return null;
        }

        // Resolve the actual paint compatibility tag from a paint item.
        // Geometry tags use the platform codename (e.g. Paint_Atlas) but paint
        // items may use the ship name (e.g. Paint_Centurion) as their RequiredTags.
        $resolved = $this->resolvePaintTagFromItem($baseTag, $allowLiveryLookup);

        if ($resolved !== null) {
            return $resolved;
        }

        // The geometry-based lookup may fail for sub-modules whose geometry
        // uses the parent ship codename (e.g. Command Module uses Caterpillar
        // geometry tags). Try the entity's own class name as a fallback.
        $className = $this->item->getClassName();
        if ($className !== '') {
            $classBase = 'Paint_'.implode('_', array_slice(explode('_', $className), 1));
            $classResolved = $this->resolvePaintTagFromItem($classBase, $allowLiveryLookup);

            if ($classResolved !== null) {
                return $classResolved;
            }
        }

        return null;
    }

    /**
     * Derive the base paint tag from a list of SubGeometry paint tag variants.
     *
     * @param  list<string>  $paintTags
     */
    private function extractBasePaintTag(array $paintTags): ?string
    {
        if (count($paintTags) === 1) {
            $lastUnderscore = strrpos($paintTags[0], '_');

            return $lastUnderscore !== false ? substr($paintTags[0], 0, $lastUnderscore) : $paintTags[0];
        }

        // CIG ships miscased SubGeometry tags ("..._Mk5_..." next to "..._mk5_..."):
        // compare case-insensitively and vote per character so neither the base nor its casing depends on tag order.
        $prefix = strtolower($paintTags[0]);

        for ($i = 1, $count = count($paintTags); $i < $count; $i++) {
            $tag = strtolower($paintTags[$i]);

            while (! str_starts_with($tag, $prefix)) {
                $prefix = substr($prefix, 0, -1);

                if ($prefix === '') {
                    return null;
                }
            }
        }

        $voted = '';

        for ($pos = 0, $length = strlen($prefix); $pos < $length; $pos++) {
            $votes = [];

            foreach ($paintTags as $tag) {
                $char = $tag[$pos];
                $votes[$char] = ($votes[$char] ?? 0) + 1;
            }

            ksort($votes);
            arsort($votes);

            $voted .= (string) array_key_first($votes);
        }

        return rtrim($voted, '_');
    }

    /**
     * Look up a paint item by class name and return its RequiredTags.
     *
     * Paint items carry the authoritative compatibility tag in their AttachDef@RequiredTags.
     * Promotion of explicit port tags requires a template because geometry lists may be incomplete.
     */
    private function resolvePaintTagFromItem(string $baseTag, bool $allowLiveryLookup): ?string
    {
        $itemService = ServiceFactory::getItemService();

        // Try exact class name lookups for well-known suffixes.
        // Some templates (e.g. Paint_Gladius_Default) exist but have no
        // RequiredTags - continue searching for a better match.
        foreach (['_Template', '_Base', '_Default'] as $suffix) {
            $item = $itemService->getByClassNameIgnoringCase($baseTag.$suffix);

            if ($item !== null) {
                $tag = $item->getRequiredTagList()[0] ?? null;

                if ($tag !== null) {
                    return $tag;
                }
            }
        }

        if ($allowLiveryLookup && substr_count($baseTag, '_') >= 1) {
            foreach ($itemService->getByClassNamePrefix($baseTag.'_') as $item) {
                $tag = $item->getRequiredTagList()[0] ?? null;

                if ($tag !== null) {
                    return $tag;
                }
            }
        }

        return null;
    }

    /**
     * Average Min/Max values across shields for a given key path.
     * Key path is like 'Shield.Resistance' which resolves to stdItem.Shield.Resistance.
     * The value at that path is expected to be [DamageType => [Minimum => float, Maximum => float], ...]
     *
     * @param  array<int, array>  $shields  stdItem arrays for active shields
     * @return array<string, array{Minimum: float, Maximum: float}>|null
     */
    private function averageShieldMinMax(array $shields, string $keyPath): ?array
    {
        if ($shields === []) {
            return null;
        }

        $result = [];
        $count = count($shields);

        foreach (self::$resistanceKeys as $type) {
            $minSum = 0.0;
            $maxSum = 0.0;
            $hasData = false;

            foreach ($shields as $stdItem) {
                $values = Arr::get($stdItem, "{$keyPath}.{$type}");

                if (is_array($values)) {
                    $minSum += (float) ($values['Minimum'] ?? 0.0);
                    $maxSum += (float) ($values['Maximum'] ?? 0.0);
                    $hasData = true;
                }
            }

            if ($hasData) {
                $result[$type] = [
                    'Minimum' => round($minSum / $count, 4),
                    'Maximum' => round($maxSum / $count, 4),
                ];
            }
        }

        return $result !== [] ? $result : null;
    }

    /**
     * Recursively mark loadout entries whose hardpoint is bridge-controllable.
     */
    private function markPilotSlaveable(array &$loadout, array $turretControlMap): void
    {
        $slaveableSet = array_flip($turretControlMap);

        foreach ($loadout as &$entry) {
            $hardpointName = $entry['HardpointName'] ?? null;

            if ($hardpointName !== null && isset($slaveableSet[$hardpointName])) {
                $entry['IsPilotSlaveable'] = true;
            }

            if (isset($entry['Loadout']) && is_array($entry['Loadout'])) {
                $this->markPilotSlaveable($entry['Loadout'], $turretControlMap);
            }
        }
    }
}
